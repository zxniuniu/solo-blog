title: How to Run Java Program Automatically on Tomcat Startup
date: '2018-10-09 21:59:23'
updated: '2019-10-15 09:53:54'
tags: [Tomcat, Java]
permalink: /articles/2018/10/09/1539064578164.html
---
Recently I wanted to start my standalone Java Application on Tomcat Startup. Also found so many other related questions on net. i.e.

![ApacheTomcatCrunchifyTipsjpg](https://raw.githubusercontent.com/zxniuniu/solo_backup/master/903211d508ce4b59819f6b8e2be902d4_ApacheTomcatCrunchifyTips.jpg) 

*   I need to run an application that can run automatically that when the tomcat starts..? any suggestions…?
*   how can I start my application by default on tomcat server start/restart?
*   Is it possible to `edit` tomcat startup services?
*   How to Start a service `automatically` when the tomcat starts

To run java program automatically on tomcat startup, need to use Servlet and this Servlet initialized on tomcat startup automatically.

To execute a program, you have to use `Servlet` and Servlet should define in deployment descriptor `web.xml` file under `WEB-INF` folder.

web.xml file contain tags `` and `` tag. Servlet tag keeps information of Servlet class. When tomcat starts, all Servlet loads in web container and init method of Servlet loaded first. Any java statement in `init method` of Servlet can be executed on running tomcat startup batch or shell.

In init method we can define our scripts which have to be executed e.g. sending emails, sending newsletters, starting scheduler, etc..

### Below is a simple trick to run your java program automatically on Tomcat Startup.

### Step-1

Modify Web.xml file with below information. Where `CrunchifyServletExample` is a class name and `crunchify.com.tutorials` is a package name.

Modify these values as per your need.

```xml
<servlet>

    <servlet-name>CrunchifyTutorials</servlet-name>
    crunchify.com.tutorials.CrunchifyServletExample
    <load-on-startup>1</load-on-startup>

</servlet>
```

This is my complete  `web.xml` file

```xml
<?xml version="1.0"  encoding="UTF-8"?>

http://www.w3.org/2001/XMLSchema-instance"  xmlns="http://java.sun.com/xml/ns/javaee"  xmlns:web="http://java.sun.com/xml/ns/javaee/web-app_2_5.xsd"  xsi:schemaLocation="http://java.sun.com/xml/ns/javaee http://java.sun.com/xml/ns/javaee/web-app_3_0.xsd"  version="3.0">

  <display-name>CrunchifyTutorials</display-name>
  
  <welcome-file-list>
    <welcome-file>index.html</welcome-file>
    <welcome-file>index.htm</welcome-file>
    <welcome-file>index.jsp</welcome-file>
    <welcome-file>default.html</welcome-file>
    <welcome-file>default.htm</welcome-file>
    <welcome-file>default.jsp</welcome-file>
  </welcome-file-list>

  <servlet>
    <servlet-name>CrunchifyTutorials</servlet-name>
    crunchify.com.tutorials.CrunchifyServletExample
    <load-on-startup>1</load-on-startup>
  </servlet>

</web-app>
```

### Step-2  CrunchifyServletExample.java

```java
package  crunchify.com.tutorials;

import  javax.servlet.*;
import  javax.servlet.http.HttpServlet;

/**
* @author Crunchify.com
*/
@SuppressWarnings("serial")
public  class  CrunchifyServletExample  extends  HttpServlet{

    public  void  init()  throws  ServletException{
          System.out.println("----------");
          System.out.println("---------- CrunchifyServletExample Initialized successfully ----------");
          System.out.println("----------");
    }
}
```

### Step-3

Now Clean your project using Maven or `Project Menu` -> `Clean`

### Step-4

*   Deploy your project to Tomcat
*   Start Tomcat
*   Check your `system out logs` and you should see output like this

Console Output

```
----------
----------  CrunchifyServletExample Initialized successfully  ----------
----------
```

Enjoy and Happy Coding..

感谢原作者，博客转自：https://crunchify.com/how-to-run-java-program-automatically-on-tomcat-startup
