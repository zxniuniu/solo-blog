title: 可高级自定义的开源 Piwigo 相册，您的照片管理、浏览专家【强烈推荐】
date: '2019-10-10 17:08:59'
updated: '2019-12-29 15:17:02'
tags: [工具, 相册]
permalink: /articles/2019/10/10/1570698539034.html
---
**Piwigo** 是一款基于Web网页的开源图片管理系统，其带有非常简单的安装界面和管理面板，具有强大的功能来发布、管理、浏览您的照片，并且众多的扩展插件使Piwigo定制更加轻松，锦上添花。更令人振奋的是Piwigo是完全免费及源码开放的。
Piwigo 提供了一系列丰富的功能，可设置图片自由/限制访问，以及角色/用户管理，多服务器支持，用户评论支持，采用模板控制界面外观，多语言支持，多目录支持（每一张图片可以同时属于多个目录）。Piwigo 每年都在更新，新功能取决于程序小组的新想法和与社区会员的讨论。

![piwigo.jpg](https://img.hacpai.com/file/2019/10/piwigo-bcafc0dc.jpg)

### 示例演示

你可以先通过演示示例了解Piwigo的各项功能。

* [官方演示示例 https://cn.piwigo.org/demo/index.php?/categories&lang=zh_CN](https://cn.piwigo.org/demo/index.php?/categories&lang=zh_CN) 

![piwigodemo.jpg](https://img.hacpai.com/file/2019/10/piwigodemo-c9eaceae.jpg)

* [https://demo.piwigo.com/index](https://demo.piwigo.com/index)

![piwigocom.jpg](https://img.hacpai.com/file/2019/10/piwigocom-3de98332.jpg)

* [小妞图库 http://niuniu.hicp.net](http://niuniu.hicp.net)

即本人的图库地址，为防泄露隐私，图片虚化了^_^。另外，暂未开放个人私有照片，点开上面的链接可能什么也看不到，后面我会将非个人私有照片进行公开，目前正整理照片中。

![piwigozxniuniu.jpg](https://img.hacpai.com/file/2019/10/piwigozxniuniu-6751f577.jpg)

### 功能介绍

#### 添加照片

* 使用浏览器**直接上传** 是最简单直接的方法。这要看您浏览器和服务器的性能。如果您要上传大批量的图片，或者上传过程中遇到了一些问题，那么可以尝试另外的一些方法。

* 有许多桌面或手机 **应用程序** 可以向Piwigo中添加图片。

![piwigoapp.jpg](https://img.hacpai.com/file/2019/10/piwigoapp-6089e380.jpg)

* **FTP 上传** 是非常推荐的方法，可以一次性上传大批量的相片。以下向导将教您如何准备您的相片。使用 FTP 方式，您可以很精确地控制您服务器上的相片目录的物理结构。

![piwigoftp.jpg](https://img.hacpai.com/file/2019/10/piwigoftp-7d738994.jpg)

#### Piwigo Remote Sync  
  
[Piwigo Remote Sync]([https://github.com/Piwigo/Piwigo-Java](https://github.com/Piwigo/Piwigo-Java))  
  
Piwigo Remote Sync 是Piwigo照片库软件的上传同步工具，该工具能够上传整个文件夹目录结构。多次运行，仅上传新的文件夹/照片到服务器中。  
  
![PiwigoRemoteSync.png](https://img.hacpai.com/file/2019/10/PiwigoRemoteSync-7e8164bc.png)  
![PiwigoRemoteSync2.png](https://img.hacpai.com/file/2019/10/PiwigoRemoteSync2-957da780.png)  
![PiwigoRemoteSync3.png](https://img.hacpai.com/file/2019/10/PiwigoRemoteSync3-d9527358.png) 
![PiwigoRemoteSync4.png](https://img.hacpai.com/file/2019/10/PiwigoRemoteSync4-11c63b32.png)

#### 批量管理
过滤图库中的图片，批量进行选择并执行操作：修改作者、添加一些标签、关联到一个新的相册、设置地理位置……

![https://cn.piwigo.org/plugins/piwigo-piwigodotorg/images/features/piwigo-features-batch-manager.png](https://cn.piwigo.org/plugins/piwigo-piwigodotorg/images/features/piwigo-features-batch-manager.png)

#### 相册管理

在自己的相册中发布你的照片。 相册层级没有限制。 一张图片可归属到多个相册。

#### 按日期浏览

数码相机会将日期存储在照片中，Piwigo 会利用日期信息在日历上显示您的照片集，让您可以按日期浏览。

#### 照片权限

给照片添加私密属性并决定谁可以看到它们。 可以按用户组或单个用户设定相册与图片的访问权限。

#### 定位照片拍摄地点

Piwigo 能够从照片的元数据中读取GPS经纬度。 然后，依靠 Google Maps 或 OpenStreetMap，Piwigo 可以在一张互动地图上显示您拍的照片。

![screenshot-piwigo-geolocation.jpg](https://cn.piwigo.org/plugins/piwigo-piwigodotorg/images/features/screenshot-piwigo-geolocation.jpg)

#### 用户管理

管理员可以创建用户、组，管理权限并发送通知。 数位管理员能够同时管理 Piwigo。 非常适合您管理整个家族的照片！

![piwigo-features-user-manager.png](https://cn.piwigo.org/plugins/piwigo-piwigodotorg/images/features/piwigo-features-user-manager.png)

#### 组织管理分类

通过您的分类来分发您的相片。分类树是没有深度限制的。每个相片可以属于多个分类。

#### 标签进行标记

为您的访客提供另一个浏览您相片的方式，从标签云和相关标签开始让选择的次数减少。

#### 按日期浏览

数码相机会将拍摄日期保存在相片里，Piwigo会使用此日期来将您的相片集显示在日历上，使您可按日子来浏览。

![piwigodate.jpg](https://img.hacpai.com/file/2019/10/piwigodate-b01e1f36.jpg)

#### 照片隐私

让您的相片成为隐私，并决定哪些人可查看它们。您可以为用户组或者某一用户在分类和相片里设置权限。

#### 主题和插件

通过主题改变外观。通过插件添加功能。只需点击几下就可以安装这些扩展。有350个可用的扩展，并且还在不断增加中！

![piwigotheme.jpg](https://img.hacpai.com/file/2019/10/piwigotheme-99d502e7.jpg)

![piwigoplugins.jpg](https://img.hacpai.com/file/2019/10/piwigoplugins-db2fc6d4.jpg)

#### 访客评论

您的访客可以发表评论，可以评分，设置喜爱的相片，执行搜索，并可通过电子邮件或RSS源得到网站最新消息。

#### 官方更新

![piwigochangelog.jpg](https://img.hacpai.com/file/2019/10/piwigochangelog-69645537.jpg)

#### 统计和管理工具

管理员可以浏览历史记录，批量处理相片，验证评论和用户相片，添加固定链接或者管理远程服务器。

#### 支持 Android 查看

[https://github.com/Piwigo/Piwigo-Android](https://github.com/Piwigo/Piwigo-Android)

可在Android等设备上使用软件直接查看图片，虽然现在软件功能还比较少哈。

![01Login.jpg](https://img.hacpai.com/file/2019/10/01Login-73681143.jpg)

![04Albumshorizontal.jpg](https://img.hacpai.com/file/2019/10/04Albumshorizontal-525136ea.jpg)

* 自动幻灯片放映
* 使用EXIF/IPTC源数据填写相片属性，如标题和标签
* 通过 RV Maps & Earth 插件在地图上浏览相片
* 从其他应该程序来执行一个 web API , 如通过 PiwigoPress 在 WordPress 博客里显示 Piwigo 的缩略图
* 对搜索引擎优化(SEO)了有意义的URL地址，包括 标签/分类/相片名
* 预定义了一组相片，如最高评分的，最多人看的，随机或者最新发布的相片等
* 结合多种浏览方式的能力：显示所有在 2019年9月拍摄的相片标签 "niuniu" + "zx"
* 使用 Additional Pages 插件添加 HTML 页面
* 简易的安装和升级easy installation and upgrades
* 高级的过滤垃圾广告技术
* 可让您充分制定的多种配置选项，让 Piwigo 适合您的需求

### Piwigo安装、升级指南

最后一部分，Piwigo安装及升级，官方有非常详细的教程，基本上是傻瓜式安装！

#### 手动安装

使用手工安装方式，您需要从 Piwigo 网站上下载完整的程序代码文件，然后解压并将其上传到您的服务器。

[安装指引:手工安装](https://cn.piwigo.org/doc/doku.php?id=安装指引:手工安装)

[升级指南:手工升级](https://cn.piwigo.org/doc/doku.php?id=升级指南:手工升级)

#### 网络安装

网络安装需要上传一个文件到你的服务器。此文件包含了从 [Piwigo.org](https://cn.piwigo.org/doc/Piwigo.org) 网站下载的 Piwigo 文档，然后解压进行安装。

[安装指引:网络安装](https://cn.piwigo.org/doc/doku.php?id=安装指引:网络安装)

[升级指南:自动升级](https://cn.piwigo.org/doc/doku.php?id=升级指南:自动升级)

### 结论

个人觉得很好用，07年之后的照片全部在Piwigo上管理浏览，这也用了两年多了，看照片什么的很方便。总之，强烈推荐使用！！！

如何通过不限速免费服务器在随时随地查看相册图片、视频，请参见：[Frp 内网穿透，实现个人相册、视频随时随地查看](https://fuyiyi.imdo.co/articles/2019/12/29/1577603429222.html)

参见：https://www.maketecheasier.com/make-a-custom-web-gallery-with-piwigo
