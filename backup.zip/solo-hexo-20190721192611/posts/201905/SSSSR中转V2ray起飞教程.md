title: SS/SSR中转V2ray起飞教程
date: '2019-05-23 18:45:11'
updated: '2019-05-23 18:57:47'
tags: [翻墙, 网络, 性能优化, 安全]
permalink: /articles/2019/05/23/1558608311047.html
---
## 前言

目前市面上已经有很多机场（提供 SS/SSR 服务的网站），且不乏众多公益机场，这些机场因为拥有一些好线路的服务器，所以在使用的时候可以获得较好的突破网络封锁的体验。比起自己购买一个垃圾服务器，使用时的龟速；以及购买一个优质线路服务器，承受每月高额费用；更不用说还要担心自己服务器被 GFW 认证的风险——使用机场真是省钱省心。但是隐私问题也不容小觑，支付时的隐私泄露按下不表，本文的初衷是规避使用机场时流量隐私泄露的问题——如何使用机场服务的同时不暴露自己的流量隐私。

V2Ray 除了支持自有协议 VMess 之外，还支持 Socks、Shadowsocks 等协议，配合自带的流量中转功能，可以在保护流量隐私的同时，借助机场起飞，最大程度上提升代理使用体验。

前面说这么多，说人话就是——花最少的钱，用最好的线路，让偷窥流量 / 监控流量的机场见鬼去吧。

## 基本原理

![ssssrtov2ray.png](https://img.hacpai.com/file/2019/05/ssssrtov2ray-76f51eaf.png)

基本原理大致如下：

1. V2Ray 客户端先将流量使用 VMess 协议加密
2. 按照不同的加密方法：  
    * SS 中转：V2Ray 客户端再使用 SS 协议加密，把两次加密后的流量发送到机场服务器进行中转  
    * SSR 中转：V2Ray 客户端把 VMess 加密流量发给 SSR 客户端，SSR 客户端再使用 SSR 协议加密，把两次加密后的流量发送到机场服务器进行中转
3. 机场服务器对流量进行 SS/SSR 解密后再把流量（VMess 协议加密流量）发往我们自建的 V2Ray 服务器
4. V2Ray 服务器正常访问网站
5. 网站返回的数据按上述步骤和处理方式原路返回

由于机场服务器收到的是 VMess 协议加密后的流量，加密方法又是我们自定义的，所以机场几无可能掌握我们的真实流量。

## SS 中转 V2Ray 流量

V2Ray 自身支持 Shadowsocks 协议，所以 SS 中转 V2Ray 流量按照官方的[白话文教程-代理转发](https://toutyrater.github.io/advanced/outboundproxy.html)来操作就行了。简单来说就是把配置文件中的`outbounds`部分设置为这样：  

```
{
  "outbounds": [
    {
      "protocol": "vmess",
      "settings": { // 此处根据自己的V2Ray设置修改
        "vnext": [
          {
            "address": "1.1.1.1",
            "port": 8888,
            "users": [
              {
                "alterId": 64,
                "id": "b12614c5-5ca4-4eba-a215-c61d642116ce"
              }
            ]
          }
        ]
      },
      "proxySettings": {
          "tag": "transit"  // 把 V2Ray 流量发给 tag 名为 transit 的代理进行转发
        }
    },
    {
      "protocol": "shadowsocks",
      "settings": { // 此处填上机场某个 SS 服务器的配置
        "servers": [
          {
            "address": "2.2.2.2",
            "method": "aes-256-cfb",
            "ota": false,
            "password": "password",
            "port": 1024
          }
        ]
      },
      "tag": "transit"
    }
  ]
```

## SSR 中转 V2Ray 流量

但是很多机场都是 SSR 机场，没有提供 SS 配置，那岂不是就不能用上面的骚操作了？既然 SSR 支持监听本地的 Socks 流量，V2Ray 又支持 Socks 协议传出，那我们只需要在本地同时打开 V2Ray 和 SSR 客户端，然后用 Socks 协议连接二者通信即可，相当于把上一节中 V2Ray 传出目标从服务器改为本地 SSR。那么配置文件中的`outbounds`部分就设置为这样：  

```
{
  "outbounds": [
    {
      "protocol": "vmess",
      "settings": { // 此处根据自己的V2Ray设置修改
        "vnext": [
          {
            "address": "1.1.1.1",
            "port": 8888,
            "users": [
              {
                "alterId": 64,
                "id": "b12614c5-5ca4-4eba-a215-c61d642116ce"
              }
            ]
          }
        ]
      },
      "proxySettings": {
          "tag": "transit"  // 把 V2Ray 流量发给 tag 名为 transit 的代理进行转发
        }
    },
    {
      "protocol": "socks",
      "settings": {
        "servers": [
          {
          "address": "127.0.0.1",
          "port": 1080  // 此处填写 SSR 客户端监听的本地端口
          }
        ]
      },
      "tag": "transit"
    }
  ]
```

以 Windows 平台为例，我们可以在客户端的「选项设置」中「允许来自局域网的连接」，并且设置 SSR 客户端监听的本地端口：

![ssrsetting.png](https://img.hacpai.com/file/2019/05/ssrsetting-e68f4492.png)

完成设置后，在 SSR 客户端中选择想要使用的服务器节点，并且打开 V2Ray，需要代理的流量全部访问**V2Ray 客户端监听的端口**即可。

![ssrselect.png](https://img.hacpai.com/file/2019/05/ssrselect-f9694ade.png)

如果设置正确，访问不存在的网站时，可以在 V2Ray 服务端日志中看到流量全部来自于我们选择机场服务器节点。

![ssrlog.png](https://img.hacpai.com/file/2019/05/ssrlog-ec150c8b.png)

## V2Ray 配置文件

刚开始使用 V2Ray 的人可能会困惑于 V2Ray 配置文件的繁琐，下面提供几个与本文相关的，本人目前正在使用的 V2Ray 完整配置文件，其中客户端配置文件集成了基本的广告屏蔽和大陆直连，本地监听端口为`1082`，可根据自己需要进行修改。同时也提供了最简单的服务端配置文件，仅供参考：

*   [SS 中转 V2Ray 客户端配置文件](https://gist.github.com/yhyy135/667251599e3e762ca6d86517d39554c8/raw/ba48ac317c5b658b55b4834516d897a4a201a473/ss-vmess-config.json)
*   [SSR 中转 V2Ray 客户端配置文件](https://gist.github.com/yhyy135/667251599e3e762ca6d86517d39554c8/raw/ba48ac317c5b658b55b4834516d897a4a201a473/ssr-vmess-config.json)
*   [V2Ray 服务端配置文件](https://gist.github.com/yhyy135/667251599e3e762ca6d86517d39554c8/raw/ba48ac317c5b658b55b4834516d897a4a201a473/server-config.json)

另外，由于 SSR 中转 V2Ray 流量需要同时使用 SSR 客户端和 V2Ray 客户端，所以目前暂时无法在移动设备上实现，略有遗憾。

感谢原作者，博客转自：https://acuario.xyz/delegate-v2ray-traffic-to-ss-or-ssr/