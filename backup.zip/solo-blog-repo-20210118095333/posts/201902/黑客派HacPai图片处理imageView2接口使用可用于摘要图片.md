title: 黑客派（HacPai）图片处理 imageView2 接口使用，可用于摘要图片
date: '2019-02-26 16:36:20'
updated: '2019-10-15 10:19:25'
tags: [Solo, 接口, Q&A, 性能优化]
permalink: /articles/2019/02/25/1551085983283.html
---
黑客派博客`Solo`配图可使用`imageView2`接口显示不同大小的摘要图，通过给定参数 `imageView2` 可调整图片的大小，使之显示出来比较美观，但是参数具体代表什么含义，看完这篇博文你就知道，也自己留个底，方便后面查看。
![](https://img.hacpai.com/bing/20180406.jpg?imageView2/1/w/960/h/400/interlace/1/q/100) 

### **描述**

imageView2是原imageView接口的更新版本，实现略有差异，功能更为丰富。同样，只需要填写几个参数即可对图片进行缩略操作，生成各种缩略图。imageView2接口可支持处理的原图片格式有`psd、jpeg、jpg、png、gif、webp、tiff、bmp`。

### **接口规格**

注意：接口规格**`不含任何空格及换行符`**：

```
imageView2/<mode>                     // 模式，可选值：0, 1, 2, 3, 4, 5
          /w/<LongEdge>               // 宽度，长边
          /h/<ShortEdge>              // 高度，短边
          /format/<Format>            // 图片模式，可选值：
          /interlace/<Interlace>      // 渐进显示，可选值：0, 1；仅对jpg有效；默认0，不渐进显示
          /q/<Quality>                // 显示质量，默认值
```

其中`<mode>`分为如下几种情况：

<style> table th:nth-of-type(1) { width: 210px; } </style>

| 模式 | 说明 |
| --- | --- |
| `/0/w/<LongEdge>/h/<ShortEdge>` | 限定缩略图的长边最多为`<LongEdge>`，短边最多为`<ShortEdge>`，进行等比缩放，不裁剪</br> * 若只指定` w `参数则表示限定长边，短边自适应</br> * 若只指定` h `参数则表示限定短边，长边自适应 |
| `/1/w/<Width>/h/<Height>` | 限定缩略图的宽最少为`<Width>`，高最少为`<Height>`，进行等比缩放，居中裁剪</br>* 裁剪后的缩略图通常恰好是`<Width>x<Height>`的大小，缩放时超出矩形框的边会被裁剪掉</br>* 若只指定 w 参数或只指定 h 参数，代表限定为长宽相等的正方形图 |
| `/2/w/<Width>/h/<Height>` | 限定缩略图的宽最多为`<Width>`，高最多为`<Height>`，进行等比缩放，不裁剪</br>如果只指定 w 参数则表示限定宽（长自适应），只指定 h 参数则表示限定长（宽自适应）。它和模式0类似，区别只是限定宽和高，不是限定长边和短边。从应用场景来说，模式0适合移动设备上做缩略图，模式2适合PC上做缩略图。 |
| `/3/w/<Width>/h/<Height>` | 限定缩略图的宽最少为`<Width>`，高最少为`<Height>`，进行等比缩放，不裁剪。如果只指定 w 参数或只指定 h 参数，代表长宽限定为同样的值。你可以理解为模式1是模式3的结果再做居中裁剪得到的。 |
| `/4/w/<LongEdge>/h/<ShortEdge>` | 限定缩略图的长边最少为`<LongEdge>`，短边最少为`<ShortEdge>`，进行等比缩放，不裁剪。如果只指定 w 参数或只指定 h 参数，表示长边短边限定为同样的值。这个模式很适合在手持设备做图片的全屏查看（把这里的长边短边分别设为手机屏幕的分辨率即可），生成的图片尺寸刚好充满整个屏幕（某一个边可能会超出屏幕）。 |
| `/5/w/<LongEdge>/h/<ShortEdge>` | 限定缩略图的长边最少为`<LongEdge>`，短边最少为`<ShortEdge>`，进行等比缩放，居中裁剪。如果只指定 w 参数或只指定 h 参数，表示长边短边限定为同样的值。同上模式4，但超出限定的矩形部分会被裁剪。 |

**注意：**

*   可以仅指定`w`参数或`h`参数
*   新图的宽/高/，长边/短边，不会比原图大，即接口总是缩小图片
*   所有模式都可以只指定`w`参数或只指定`h`参数
    * 在`w、h`为限定最大值时，未指定某参数等价于将该参数设置为自适应
    * 在`w、h`为限定最小值时，未指定参数等于给定的参数，也就限定的矩形是正方形
*   处理后的图片`w`和`h`参数不能超过9999像素，总像素不得超过24999999（2500万-1）像素
*   处理前的图片`w`和`h`参数不能超过3万像素，总像素不能超过1.5亿像素

| 参数名称 | 说明 |
| --- | --- |
| `/format/` | 新图的输出格式取值范围：`jpg`，`gif`，`png`，`webp`等，默认为原图格式。参考[支持转换的图片格式](http://www.imagemagick.org/script/formats.php)。 |
| `/interlace/<Interlace>` | 是否支持渐进显示<br>取值范围：`1`支持渐进显示，`0`不支持渐进显示(默认为0)。<br>适用目标格式：`jpg`  <br>效果：网速慢时，图片显示由模糊到清晰。 |
| `/q/<Quality>` | 新图的图片质量<br>取值范围是[1, 100]，默认75。<br>● 指定值后面可以增加`!`，表示强制使用指定值，如`100!`。  <br>● 支持图片类型：jpg。 |
| `/ignore-error/<ignoreError>` | 可选取值：`1` <br>● 未设置此参数时，正常返回处理结果。<br>● 设置了此参数时，若图像处理的结果失败，则返回原图。<br>● 设置了此参数时，若图像处理的结果成功，则正常返回处理结果。 |

`<Quality>`修正值算法：
● 原图quality <= 90: **min[90, 原图quality*sqrt(原图长宽乘积/结果图片长宽乘积)]**
● 原图quality > 90: **原图quality*sqrt(原图长宽乘积/结果图片长宽乘积)**

### **示例** ### 

```
模块0，仅指定高度： image_path?imageView2/0/h/200 
```
![缩略图](https://img.hacpai.com/bing/20180406.jpg?imageView2/0/h/200) 
---
```
模块1，仅指定高度： image_path?imageView2/1/h/200 
```
![缩略图](https://img.hacpai.com/bing/20180406.jpg?imageView2/1/h/200) 
---
```
模块2，仅指定高度： image_path?imageView2/2/h/200 
```
![缩略图](https://img.hacpai.com/bing/20180406.jpg?imageView2/2/h/200) 
---
```
模块3，仅指定高度： image_path?imageView2/3/h/200 
```
![缩略图](https://img.hacpai.com/bing/20180406.jpg?imageView2/3/h/200) 
---
```
模块4，仅指定高度： image_path?imageView2/4/h/200 
```
![缩略图](https://img.hacpai.com/bing/20180406.jpg?imageView2/4/h/200) 
---
```
模块5，仅指定高度： image_path?imageView2/5/h/200 
```
![缩略图](https://img.hacpai.com/bing/20180406.jpg?imageView2/5/h/200) 
---

```
模块0，指定宽高： image_path?imageView2/0/h/200/w/200 
```
![缩略图](https://img.hacpai.com/bing/20180406.jpg?imageView2/0/h/200/w/200) 
---
```
模块1，指定宽高： image_path?imageView2/1/h/200 /w/200
```
![缩略图](https://img.hacpai.com/bing/20180406.jpg?imageView2/1/h/200/w/200) 
---
```
模块2，指定宽高： image_path?imageView2/2/h/200/w/200
```
![缩略图](https://img.hacpai.com/bing/20180406.jpg?imageView2/2/h/200/w/200) 
---
```
模块3，指定宽高： image_path?imageView2/3/h/200/w/200 
```
![缩略图](https://img.hacpai.com/bing/20180406.jpg?imageView2/3/h/200/w/200) 
---
```
模块4，指定宽高： image_path?imageView2/4/h/200/w/200 
```
![缩略图](https://img.hacpai.com/bing/20180406.jpg?imageView2/4/h/200/w/200) 
---
```
模块5，指定宽高： image_path?imageView2/5/h/200/w/200 
```
![缩略图](https://img.hacpai.com/bing/20180406.jpg?imageView2/5/h/200/w/200) 
---

```
image_path?imageView2/1/w/200/h/200
```
![缩略图](https://img.hacpai.com/bing/20180406.jpg?imageView2/1/w/200/h/200)
---

* 指定图片高度和宽度，裁剪图片：
```
image_path?imageView2/1/w/960/h/270/interlace/1/q/100
```
![缩略图](https://img.hacpai.com/bing/20180406.jpg?imageView2/1/w/960/h/270/interlace/1/q/100)
---

* 指定图片质量，取值范围是[1, 100]，默认75，此处为1：
```
image_path?imageView2/1/interlace/1/q/1
```
![缩略图](https://img.hacpai.com/bing/20180406.jpg?imageView2/1/interlace/1/q/1)
---

* 渐进显示图片：
```
image_path?imageView2/1/interlace/1 
```
![缩略图](https://img.hacpai.com/bing/20180406.jpg?imageView2/1/interlace/1)
