title: 解决梯子在GFWList模式下不能正常看流媒体的问题
date: '2018-11-19 18:31:35'
updated: '2019-10-15 10:12:12'
tags: [代理, SS, 加密安全, 爬虫]
permalink: /articles/2018/10/26/1540532958285.html
---
## 问题场景：

客户端使用GFWList模式时观看流媒体。

## 问题描述：

*   当使用全局模式或大陆白名单模式时，可以观看流媒体
*   当使用GFWList模式时，无法观看（例如HBO NOW）
*   当使用GFWList模式时，可以观看，但有卡顿（例如YouTube）

![](https://i0.wp.com/myharbour.net/wp-content/uploads/2018/03/HBO-Now-Error.png?resize=1060%2C596)

###### HBO NOW在GFWList下的报错 Not in Service Area

## 问题分析：

流媒体CDN服务器的域名被GFWList识别为大陆网站。

若CDN服务区的域名不通过proxy访问，而是直达，流媒体网站可能会判定此连接非法。

## 解决方案：

添加相关域名至**GFW列表（_不同平台客户端的称谓不同_）**

### Windows客户端配置：

编辑Windows客户端文件夹中的user-rules.txt

![](https://i0.wp.com/www.myharbour.website/wp-content/uploads/2018/08/user-rules.png?zoom=1.25&resize=193%2C230)

输入相应域名（**格式为||域名**），保存文件

![](https://i1.wp.com/www.myharbour.website/wp-content/uploads/2018/08/user-rules-full.png?resize=606%2C319)

选择**PAC – 更新PAC为GFWList**

![](https://i1.wp.com/www.myharbour.website/wp-content/uploads/2018/08/PAC-GFWList.png?resize=492%2C243)

重新连接，即可正常观看HBO NOW

![](https://i2.wp.com/myharbour.net/wp-content/uploads/2018/06/HBO-NOW.jpg?resize=1060%2C596)

## 结语：

**GFW列表**并不完整，遇到类似问题，可能需要通过抓包来找出其中缺失的域名。

## 附：流媒体必须经过代理的域名

### [Netflix](https://www.netflix.com/)

*   fast.com
*   netflix.com
*   netflix.net
*   nflxext.com
*   nflximg.net
*   nflxso.net
*   nflxvideo.net

### [Amazon Prime](https://www.amazon.com/)

*   amazon.com
*   amazon.co.jp
*   amazon.co.uk
*   amazon.de
*   amazonvideo.com
*   primevideo.com

### [Twitch](https://www.twitch.tv/)

*   twitch.tv

*   ttvnw.net

### [Turnin](https://tunein.com/)

*   turnin.com
*   amazon-adsystem.com
*   pubmatic.com
*   acast.com
*   adswizz.com
*   openx.net
*   crwdcntrl.net
*   agkn.com
*   radiotime.com

### [Line](https://line.me/)

*   line.me
*   naver.jp

### 主机游戏网络

*   playstation.net
*   xboxlive.com

### 部分第三方地址检测及防地址欺诈服务

*   maxmind.com
*   ifconfig.co
*   ip2location.com
*   uplynk.com


### [HBO NOW](https://play.hbonow.com/)

*   conviva.com
*   go.com
*   hbo.com
*   hbogo.com
*   hbonow.com

### [Hulu](https://www.hulu.com/)

*   hulu.com
*   huluad.com
*   huluim.com
*   hulustream.com

### [Showtime](https://www.showtime.com/)

*   sho.com
*   showtime.com

### [DirecTV NOW](https://www.directvnow.com/)

*   att.com
*   codec-cluster.org
*   conviva.com
*   directv.com
*   directvnow.com
*   dtvce.com
*   footprint.net
*   imrworldwide.com
*   inq.com
*   omtrdc.net

### [Sling TV](https://www.sling.com/)

*   adrta.com
*   adsrvr.org
*   cloudfront.net
*   crashlytics.com
*   doubleverify.com
*   fwmrm.net
*   innovid.com
*   movetv.com
*   omtrdc.net
*   scorecardresearch.com
*   serving-sys.com
*   sling.com
*   spotxchange.com
*   tremorhub.com
*   videoamp.com

### [YouTube](https://www.youtube.com/)及[YouTube TV](https://tv.youtube.com/)

*   ggpht.com
*   googleapis.com
*   googletagmanager.com
*   googleusercontent.com
*   googlevideo.com
*   gstatic.com
*   imrworldwide.com
*   ytimg.com
*   youtube.com

### 部分美国电视台

*   abc.com
*   amctv.com
*   beinsportsconnect.net
*   beinsportsconnect.tv
*   cbs.com
*   cwtv.com
*   fox.com
*   mtv.com
*   mtvnservices.com
*   nbc.com
*   nbcuni.com
*   pbs.org

### [BBC iPlayer](https://www.bbc.co.uk/iplayer)

*   bbc.co.uk
*   linwd.net

### [爱奇艺](https://www.iqiyi.com/)_（配置后会影响观看内容）_

*   iqiyi.com

### [巴哈姆特動畫瘋](https://ani.gamer.com.tw/)

*   gamer.com.tw
*   bahamut.com.tw
*   hinet.net
*   fbcdn.net
*   gvt1.com
*   digicert.com
*   viblast.com

### [Line TV](https://tv.line.me/)

*   line.me
*   line-apps.com


### [GYAO!](https://gyao.yahoo.co.jp/)

*   yahoo.co.jp
*   yimg.jp
*   brightcove.com

### [TVer](https://tver.jp/)

*   tver.jp
*   amazonaws.com
*   yahoo.co.jp
*   brightcove.com

### [AbemaTV(アベマTV)](https://abema.tv/)

*   abema.tv
*   ameblo.jp
*   akamaized.net

转自：https://www.myharbour.website/%E8%A7%A3%E5%86%B3%E5%9C%A8gfwlist%E6%A8%A1%E5%BC%8F%E4%B8%8B%E4%B8%8D%E8%83%BD%E7%9C%8B%E6%B5%81%E5%AA%92%E4%BD%93%E7%9A%84%E9%97%AE%E9%A2%98/
