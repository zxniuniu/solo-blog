title: MacType 美化 Windows10 字体，体验类 Mac 顺滑字体
date: '2019-08-09 09:26:58'
updated: '2019-10-15 10:24:54'
tags: [性能优化, 工具]
permalink: /articles/2019/08/09/1565314018351.html
---
一直以来，Windows 常常因为糟糕的字体渲染表现广为诟病，加之默认的字体时不时以点阵形式出现戳瞎双眼，而 Mac 顺滑的字体显示则让笔者在内的诸多 Windows 用户羡慕不已，不过有了 MacType 您就什么都能搞定了。

## 关于 MacType
MacType 是基于一个 GDI++ 开源项目开发的字体渲染软件，参见 [GitHub MacType](https://github.com/snowie2000/mactype/releases) ，其能一直无障碍兼容到最近的 Windows 10 。MacType 给 Windows 用户带来了优良的字体显示效果，也使得我们能够「热替换」系统默认字体而无需修改系统文件，以下为使用效果对比。

- 用 MacType 渲染的效果
![MacType2.png](https://img.hacpai.com/file/2019/08/MacType2-3d2e8afb.png)


- 系统默认（未渲染的效果）
![MacType3.png](https://img.hacpai.com/file/2019/08/MacType3-2a29d249.png)

简单来说，MacType 可以：

* 改善 Windows 字体渲染
* 热替换系统默认中易宋体

## 安装配置

首先下载 MacType，按照提示一步一步简单安装即可，安装完成后打开自动进入配置。

- [蓝奏云 - MacType](http://t.cn/AiTa0Th0)
- [GitHub - MacType](https://github.com/snowie2000/MacType)

MacType 有注册表、服务、MacTray 托盘三种加载模式，小编建议用 注册表 模式，以达到最佳的兼容模式。MacType 默认自带了好几种渲染方案，选择一种你喜欢的方案。
![342034.png](https://img.hacpai.com/file/2019/08/342034-d5d71ced.png)

配置完成后，即可开始享受一个字体渲染愉快的 Windows 了。实际上 MacType 使用过程你会遇到各种毛病，如 一些软件不能渲染，一些用宋体的软件渲染起来很难看，就需要替换系统的宋体，一些高级玩法的技巧需要自己去摸索折腾了。
![MacType570x372.png](https://img.hacpai.com/file/2019/08/MacType570x372-5461a676.png)

## 排除冲突进程

需要注意的是，部分应用可能会与 MacType 渲染存在冲突（例如 MacType 会影响 Office 2016 的安装失败），这时我们需要使用通过排除进程来使应用正常工作。

打开 MacType 安装目录下的 `MacType.ini` 中添加以下内容：​
```
[UnloadDll]
sample1.exe
sample2.exe
sample3.exe
```

将其中 `sample*.exe` 替换为所需排除的程序名即可。另外需要注意的是若使用「注册表加载模式」，配置文件的变更需要重启才能生效。

下载地址：

- [蓝奏云 - http://t.cn/AiTa0Th0](http://t.cn/AiTa0Th0)
