title: 前端 PDF 打印工具 jsPDF 打印中文时使用思源字体 [解决中文乱码]
date: '2020-11-29 19:30:09'
updated: '2020-12-12 17:36:31'
tags: [工具, 开源, GitHub]
permalink: /articles/2020/11/29/1606649409005.html
---
对于jsPdf版本1.4.0和更高版本，可以使用自定义ttf字体，如思源字体，标准jsPDF 1.5.3实现支持14种标准PDF字体。14种标准PDF字体如下：
![jspdf.png](https://b3logfile.com/file/2020/12/jspdf-cbef06c3.png)

* Courier
* Courier-Bold
* Courier-BoldOblique
* Courier-Oblique
* Helvetica
* Helvetica-Bold
* Helvetica-BoldOblique
* Helvetica-Oblique
* Symbol
* Times-Roman
* Times-Bold
* Time-Italic
* Time-BoldItalic

如果要使用上述字体之一，则可以直接使用 `setFont()` 方法进行设置，而不需要执行任何其他操作。如果使用自定义字体，则需要使用base64编码，并进行相应操作。要在PDF文件中使用自定义字体，则需要所需字体文件的.ttf版本。以下为思源字体，您可以前往 [SourceHanSansCN](https://github.com/zxniuniu/SourceHanSansCN) 下载。

![image.png](https://b3logfile.com/file/2020/11/image-ea3374cd.png)

在下载.ttf字体文件后，需要将要使用的字体上传到此 [jsPDF Font Converter](https://zxniuniu.github.io/demos/jspdf/fontconverter/fontconverter.html) 进行Base64编码，或下载[fontconverter](https://zxniuniu.github.io/demos/jspdf/fontconverter) 文件后，本地浏览器打开fontconverter.html文件转换。

注意：**不要**输入fontName字段，文件选择后会自动生成fontName名称，然后选择 fontStyle，或模块格式，然后点击Create按钮下载生成的js文件。

![image.png](https://b3logfile.com/file/2020/11/image-eb6aa8b6.png)

以下在设置具体字体时的名称 `SourceHanSansCN-Normal` 与上面的fontName名称一致。

```
doc.setFont('SourceHanSansCN-Normal', 'normal');
```

需要注意的是，经过研究，如果选择 `SourceHanSansCN-Bold.ttf` 字体时，fontStyle选择bold，生成的字体js在引用后一直不生效，经过研究，发现在fontStyle选择normal时，即采用

```
doc.setFont('SourceHanSansCN-Bold', 'normal');
```

才会生效。**个人理解是将Bold当成了一个新的normal类型的字体而已，即在设置字体时，其名称为SourceHanSansCN-Bold的新字体，且其字体类型为 `normal` 类型。**

另外，在Google上搜索的话，能够搜索到的大部分内容中均有的代码，但该代码未能直接采用配置模式进行导出设置。

```
var doc = new jsPDF('landscape'); 

doc.addFileToVFS('SourceHanSansCN-Normal-normal.ttf'，'SourceHanSansCN base64编码'); 
doc.addFont('SourceHanSansCN-Normal-normal.ttf'，'SourceHanSansCN-Normal'，'normal'); 
doc.setFont('SourceHanSansCN-Normal-normal')
```

采用配置文件方式时，需要先引入字体js文件，如下：

```
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/tableexport.jquery.plugin@1.10.21/libs/jsPDF/jspdf.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/tableexport.jquery.plugin@1.10.21/libs/jsPDF-AutoTable/jspdf.plugin.autotable.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/gh/zxniuniu/SourceHanSansCN/js/jspdf/SourceHanSansCN-Normal-normal.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/tableexport.jquery.plugin@1.10.21/tableExport.min.js"></script>
```

`tableExport`的参数如下：

```
let conf = {
	type: 'pdf',
	jspdf: {
		orientation: 'landscape', // 'portrait' or 'landscape'
		autotable: {
			styles: {
				font: 'SourceHanSansCN-Normal',
				fontStyle: 'normal'
			},
			headerStyles: {
				font: 'SourceHanSansCN-Normal',
				fontStyle: 'normal'
			},
			tableWidth: 'wrap'
		}
	}
};
$('#pdfstyles').tableExport(conf);
```

你可以打开 [jsPDF 中文字体导出-测试](https://zxniuniu.github.io/demos/jspdf/jspdf-chinese-export.html) 进行测试，全部演示代码可参见 [jsPDF 中文字体导出-源码](https://github.com/zxniuniu/demos/blob/main/jspdf/jspdf-chinese-export.html)，以下为导出结果情况。或者参见官方示例 [jsPDF Demos](https://mrrio.github.io/jsPDF/examples/basic.html)。

![20201127162143.png](https://b3logfile.com/file/2020/11/20201127162143-9e1c4445.png)

参见：

[JSPDF Custom Font Add not working - Stack Overflow](https://stackoverflow.com/questions/43590751/jspdf-custom-font-add-not-working)

[jsPDF Error – Font does not exist in vFS](https://www.onooks.com/jspdf-error-font-does-not-exist-in-vfs-vuejs)

[How to Use Custom Fonts with jsPDF](https://www.devlinpeck.com/tutorials/jspdf-custom-font)

[思源宋体，如何评价，以及如何正确使用](https://sspai.com/post/38705)

[fontconverter在线转换工具](https://peckconsulting.s3.amazonaws.com/fontconverter/fontconverter.html)

[Html pdf Chinese export solve the garbage problem in the correct posture](https://www.codetd.com/en/article/8045923)

[.html method can't handle Chinese correctly, even after used the .setFont method](https://github.com/MrRio/jsPDF/issues/2465)

[JSPDF problem FortAwesome](https://github.com/MrRio/jsPDF/issues/1309)

[Is it possible to use custom Google web fonts with jsPDF](https://stackoverflow.com/questions/51829884/is-it-possible-to-use-custom-google-web-fonts-with-jspdf)

[Add Custom font in jspdf](https://stackoverflow.com/questions/31961572/add-custom-font-in-jspdf)

[使用jsPDF生成PDF文件](https://blog.csdn.net/WeiLanShun_CSND/article/details/100666974)

[JSPDF支持中文（思源黑体）采坑之旅，JSPDF中文字体乱码解决方案](https://www.cnblogs.com/ww01/p/11496213.html)

