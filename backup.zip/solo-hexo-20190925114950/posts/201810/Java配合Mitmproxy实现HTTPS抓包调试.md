title: Java 配合 Mitmproxy 实现 HTTPS 抓包调试
date: '2018-10-11 06:31:41'
updated: '2018-10-11 07:10:46'
tags: [Mitmproxy, 抓包, Java, 代理, Python]
permalink: /articles/2018/10/10/1539181755175.html
---
### 一、Mitmproxy 简介

Mitmproxy 是一个命令行下的强大抓包工具，可以在命令行下抓取 HTTP(S) 数据包并加以分析；对于 HTTPS 抓包，首先要在本地添加 Mitmproxy 的根证书，然后 Mitmproxy 通过以下方式进行抓包：

![](https://mritd.b0.upaiyun.com/markdown/x7lir.jpg)

*   1、客户端发起一个到 Mitmproxy 的连接，并且发出HTTP CONNECT 请求
*   2、Mitmproxy作出响应(200)，模拟已经建立了CONNECT通信管道
*   3、客户端确信它正在和远端服务器会话，然后启动SSL连接。在SSL连接中指明了它正在连接的主机名(SNI)
*   4、Mitmproxy连接服务器，然后使用客户端发出的SNI指示的主机名建立SSL连接
*   5、服务器以匹配的SSL证书作出响应，这个SSL证书里包含生成的拦截证书所必须的通用名(CN)和服务器备用名(SAN)
*   6、Mitmproxy生成拦截证书，然后继续进行与第３步暂停的客户端SSL握手
*   7、客户端通过已经建立的SSL连接发送请求，
*   8、Mitmproxy通过第４步建立的SSL连接传递这个请求给服务器

### 二、抓包配置[](https://mritd.me/2017/03/25/java-capturing-https-packets-use-Mitmproxy/#%E4%BA%8C%E6%8A%93%E5%8C%85%E9%85%8D%E7%BD%AE)

#### 2.1、安装 Mitmproxy[](https://mritd.me/2017/03/25/java-capturing-https-packets-use-Mitmproxy/#21%E5%AE%89%E8%A3%85-Mitmproxy)

Mitmproxy 是由 python 编写的，所以直接通过 pip 即可安装，mac 下也可使用 brew 工具安装

```
# mac
brew install Mitmproxy
# Linux
pip install Mitmproxy
# CentOS 安装时可能会出现 "致命错误：libxml/xmlversion.h：没有那个文件或目录"
# 需要安装如下软件包即可解决
yum install libxml2 libxml2-devel libxslt libxslt-devel -y
```

#### 2.2、HTTPS 证书配置[](https://mritd.me/2017/03/25/java-capturing-https-packets-use-Mitmproxy/#22https-%E8%AF%81%E4%B9%A6%E9%85%8D%E7%BD%AE)

首先由于 HTTPS 的安全性，直接抓包是什么也看不到的；所以需要先在本地配置 Mitmproxy 的根证书，使其能够解密 HTTPS 流量完成一个中间人的角色；证书下载方式需要先在本地启动 Mitmproxy，然后通过设置本地连接代理到 Mitmproxy 端口，访问 `mitm.it` 即可，具体可查看 [官方文档](https://Mitmproxy.org/doc/certinstall.html)

**首先启动 Mitmproxy**

```
Mitmproxy -p 4000
```

**浏览器通过设置代理访问 mitm.it**

![](https://mritd.b0.upaiyun.com/markdown/unrnc.jpg)

选择对应平台并将其证书加入到系统信任根证书列表即可；对于 Java 程序来说可能有时候并不会生效，所以必须 **修改 keystore**，修改如下

```
# Linux 一般在 JAVA_HOME/jre/lib/security/cacerts 下
# Mac 在 /Library/Java/JavaVirtualMachines/JAVA_HOME/Contents/Home/jre/lib/security/cacerts
sudo keytool -importcert -alias Mitmproxy -keystore /Library/Java/JavaVirtualMachines/jdk1.8.0_77.jdk/Contents/Home/jre/lib/security/cacerts -storepass changeit -trustcacerts -file ~/.Mitmproxy/Mitmproxy-ca-cert.pem
```

#### 2.4、Java 抓包调试[](https://mritd.me/2017/03/25/java-capturing-https-packets-use-Mitmproxy/#24java-%E6%8A%93%E5%8C%85%E8%B0%83%E8%AF%95)

JVM 本身在启动时就可以设置代理参数，也可以通过代码层设置；以下为代码层设置代理方式

```
public void beforeTest(){
    logger.info("设置抓包代理......");
    System.setProperty("https.proxyHost", "127.0.0.1");
    System.setProperty("https.proxyPort", "4000");
}
```

**然后保证在发送 HTTPS 请求之前此代码执行即可，以下为抓包示例**

![](https://mritd.b0.upaiyun.com/markdown/kuzhd.jpg)

通过方向键+回车即可选择某个请求查看报文信息

![](https://mritd.b0.upaiyun.com/markdown/vfifu.jpg)

### 三、Java 其他代理设置[](https://mritd.me/2017/03/25/java-capturing-https-packets-use-Mitmproxy/#%E4%B8%89java-%E5%85%B6%E4%BB%96%E4%BB%A3%E7%90%86%E8%AE%BE%E7%BD%AE)

Java 代理一般可以通过 2 种方式设置，一种是通过代码层，如下

```
// HTTP 代理，只能代理 HTTP 请求
System.setProperty("http.proxyHost", "127.0.0.1");
System.setProperty("http.proxyPort", "9876");

// HTTPS 代理，只能代理 HTTPS 请求
System.setProperty("https.proxyHost", "127.0.0.1");
System.setProperty("https.proxyPort", "9876");

// 同时支持代理 HTTP/HTTPS 请求
System.setProperty("proxyHost", "127.0.0.1");
System.setProperty("proxyPort", "9876");

// SOCKS 代理，支持 HTTP 和 HTTPS 请求
// 注意：如果设置了 SOCKS 代理就不要设 HTTP/HTTPS 代理
System.setProperty("socksProxyHost", "127.0.0.1");
System.setProperty("socksProxyPort", "1080");
```

另一种还可以通过 JVM 启动参数设置

```
-DproxyHost=127.0.0.1 -DproxyPort=9876
```

感谢原作者，博客转自：https://mritd.me/2017/03/25/java-capturing-https-packets-use-Mitmproxy/