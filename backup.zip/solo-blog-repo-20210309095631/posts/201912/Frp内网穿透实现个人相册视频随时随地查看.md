title: Frp 内网穿透，实现个人相册、视频随时随地查看
date: '2019-12-29 15:10:29'
updated: '2019-12-29 15:17:12'
tags: [工具, 相册]
permalink: /articles/2019/12/29/1577603429222.html
---
前一段时间写了一篇关于家庭相册的文章（[可高级自定义的开源 Piwigo 相册，您的照片管理、浏览专家](https://fuyiyi.imdo.co/articles/2019/10/10/1570698539034.html)），后来有人问，如果没有服务器，又不想花（太多的）钱怎么办？可以使用花生壳进行内网穿透，开通需8元后的账户貌似就可以够用，经过测试貌似限速100M，且单月免费流量为1G（可通过分享赚取花生米兑换流量），查看相册图片没什么问题，但看视频就不行了。那么另外一种方式就是今天要写的，即使用SAKURA FRP来免费实现。

## SAKURA FRP 可以做什么
首先，SAKURA FRP 是完全免费的，并且拥有强大的服务器资源。

![20191229140230.png](https://img.hacpai.com/file/2019/12/20191229140230-9589d53a.png)

## 如何使用配置SAKURA FRP

### 官网注册账号
 [Sakura Frp — 免费高速内网穿透](https://www.natfrp.com) ，访问官网进行注册， 记住自己的账号密码。

### 添加映射

点击左侧映射列表，打开映射窗口，填写本地地址，以及本地端口，然后点击随机端口生成端口，注意，该端口即为最后公网服务器对外访问的端口，您需要记住该端口。
![image.png](https://img.hacpai.com/file/2019/12/image-66a2d43e.png)

生成随机端口时，若提示如下，重新点击随机端口，然后再点击添加即可。
![image.png](https://img.hacpai.com/file/2019/12/image-f8611e00.png)

添加成功后，如下所示，此处我的端口为11629，这个端口很重要，即上面说的要记住的端口：
![image.png](https://img.hacpai.com/file/2019/12/image-dc38d958.png)

### 软件下载
点击官网左侧软件下载，根据自己的平台进行软件下载：
![image.png](https://img.hacpai.com/file/2019/12/image-3f3c92e1.png)

### 配置
打开软件后，根据提示，输入用户名，密码：
![image.png](https://img.hacpai.com/file/2019/12/image-3b98ef10.png)

登录完成后即可看到各个服务器节点信息，选择一个节点
![image.png](https://img.hacpai.com/file/2019/12/image-924a8dcd.png)

此处，如果你不知道该选择哪个节点，你可以进官网左侧点击仪表盘，显示的有很多节点，然后打开CMD窗口，使用ping命令看下哪个节点响应速度相对较快。当然，如果你可以直接复制各服务器，写个批处理也可以。
![image.png](https://img.hacpai.com/file/2019/12/image-3167be5a.png)

```
ping s1.natfrp.com
ping s25.natfrp.com
ping s15.natfrp.org
ping s21.natfrp.org
ping s24.natfrp.org
ping s19.natfrp.org
ping s28.natfrp.org
ping s29.natfrp.org
```
![image.png](https://img.hacpai.com/file/2019/12/image-be411f10.png)

 OK，我们通过Ping发现 `江苏镇江` `s19.natfrp.org`的服务器响应最快，此时，在上面选择节点处，输入10（10对应`江苏镇江` `s19.natfrp.org`） 回车即可。
![image.png](https://img.hacpai.com/file/2019/12/image-6e324a34.png)

以上图中红色的部分，即为你最终外网访问使用的地址，即你选择的节点地址加上你上面的端口。

### 优化
你上面下载的客户端支持命令行参数，你可以直接写一个bat批处理，而不需要每次都输入用户名，密码，节点信息等。

```
SET sid=10
SET su=修改为你的用户名
SET sp=修改为你的用户名对应的密码
SET client=Sakura_frpc_windows_amd64.exe

%client% --su=%su% --sp=%sp% --sid=%sid%
```

同样地，开机自启，你可以直接快捷方式复制到启动文件夹，或者使用AlwaysUp类的软件等。

## 结论
将上述本地地址，本地端口替换为你部署的Piwigo所在地址、端口，即可通过外网直接打开你的相册，同时配合手机软件Piwigo，或PiwigoClient可直接在手机上打开相册图片，播放视频等。经与花生壳对比，使用Frp确实快了很多，毕竟打开的是图片或视频，响应速度肯定越快越好。

关于使用Piwigo配置相册请参见：[可高级自定义的开源 Piwigo 相册，您的照片管理、浏览专家](https://fuyiyi.imdo.co/articles/2019/10/10/1570698539034.html)
