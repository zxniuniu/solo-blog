title: Chrome 67版本后无法拖拽离线安装crx扩展插件的解决办法
date: '2019-08-12 10:13:13'
updated: '2019-08-15 16:13:54'
tags: [前端, 工具]
permalink: /articles/2019/08/12/1565575993052.html
---
Chrome 67版本以后通过拖拽.crx文件到【扩展程序】页面安装插件的方法已无法使用，以下为收集整理的三种解决Chrome 67版本后无法拖拽离线安装.crx格式插件的解决方法。如果需要更加详细的安装教程，请参见 [图文详解Chrome离线扩展安装方法-2019最新终极指南](http://chromecj.com/utilities/2019-01/1791.html) 中的介绍。

## 第一种：开启开发者模式即可（推荐）

Chrome  设置 → 更多工具 → 扩展程序，开启开发者模式即可！

![201809222226424830.png](https://img.hacpai.com/file/2019/08/201809222226424830-814134fe.png)

这是最简单的方法，我自己就是使用的这种方法！

## 第二种方法：修改参数

新建选项卡，打开下面地址：<a target="_blank" href="chrome://flags/#extensions-on-chrome-urls">chrome://flags/#extensions-on-chrome-urls</a>

![修改flags参数.bmp](https://img.hacpai.com/file/2019/08/修改flags参数-77c28264.bmp)

然后，将 disabled 改为 enable 重启Chrome即可解决。

## 第三种：修改文件格式，加载扩展程序

有时候要在 Chrome安装本地插件时，会报错，这时候将插件的后缀名 .crx 改为 .zip或者 .rar，然后将改好后缀名的文件解压到本地文件夹中。
在 Chrome  设置→  更多工具→ 扩展程序。

![201809222223307955.png](https://img.hacpai.com/file/2019/08/201809222223307955-a1e630d3.png)

点击上图中的【加载已解压的扩展程序】，找到刚才的解压的扩展程序即可。

参见： 

- [如何在Chrome浏览器中安装.crx离线扩展](http://chromecj.com/utilities/2014-09/181.html)
- [最新版Chrome浏览器安装扩展出现"CRX-HEADER-INVALID"解决办法](http://chromecj.com/utilities/2019-04/1971.html)
- [图文详解Chrome离线扩展安装方法-2019最新终极指南](http://chromecj.com/utilities/2019-01/1791.html)