title: Redis Windows安装配置与Jedis访问数据库
date: '2018-09-21 03:56:24'
updated: '2019-10-15 09:51:44'
tags: [Redis, 数据库]
permalink: /articles/2018/09/20/1537429625713.html
---
# 一 Redis概要

Redis是一个开源的使用ANSI C语言编写、遵守BSD协议、支持网络、可基于内存亦可持久化的日志型、Key-Value数据库，并提供多种语言的API。它通常被称为数据结构服务器，因为值（value）可以是 字符串(String), 哈希(Map), 列表(list), 集合(sets)和有序集合(sorted sets)等类型。

![1png](https://raw.githubusercontent.com/zxniuniu/solo_backup/master/9fbe435a4d714ed98c53e89cfecc7592_1.png) 

     Redis支持主从同步。数据可以从主服务器向任意数量的从服务器上同步，从服务器可以是关联其他从服务器的主服务器。

这使得Redis可执行单层树复制。存盘可以有意无意的对数据进行写操作。由于完全实现了发布/订阅机制，使得从数据库在任何地方同步树时，可订阅一个频道并接收主服务器完整的消息发布记录。同步对读取操作的可扩展性和数据冗余很有帮助。

## 1、相关网站

官网：[redis.io](http://redis.io/)

中文网：[http://www.redis.net.cn/](http://www.redis.net.cn/)

github：[https://github.com/MSOpenTech/redis](http://www.redis.net.cn/)

下载地址：[https://github.com/MSOpenTech/redis/releases](http://www.redis.net.cn/)

# 二、安装与配置Redis

## 2.1、下载最新版的Redis

打开redis在github上的网站：[https://github.com/MSOpenTech/redis/releases](https://github.com/MSOpenTech/redis/releases)，选择下载最新版的Redis，写该文字时最新版本是3.2.1版。

![2png](https://raw.githubusercontent.com/zxniuniu/solo_backup/master/3461f03a28204b31bf0a11b84e87d988_2.png) 


这里我们选择下载手动安装包Redis-x64-3.2.100.zip。如果是32位的可以下载源代码后自己编译出32位的版本，在[https://github.com/dmajkic/redis/downloads](https://github.com/dmajkic/redis/downloads)可以下载到32的安装文件，不过版本有点旧了。

![3png](https://raw.githubusercontent.com/zxniuniu/solo_backup/master/765c00b3d3fc455fba45bc1453db8f55_3.png) 

## 2.2、添加环境变量

将下载后的安装包解压到磁盘中，最好是没有中文路径，没有特殊字符的目录下，比如：d:\redis目录下。为了更加方便的使用Redis，可以添加环境变量，在“系统环境变量”中的“Path”变量下添加redis路径，如下所示：

![4png](https://raw.githubusercontent.com/zxniuniu/solo_backup/master/c57020fd5adb49fdaf60c262ced62858_4.png) 

确定后启动cmd，运行redis-server测试。

## 2.3、启动服务器

在命令模式下运行：redis-server.exe redis.windows.conf，如果运行提示未找到conf文件，则把参数中的配置文件路径加上，如：

![5png](https://raw.githubusercontent.com/zxniuniu/solo_backup/master/28dcd3512543415f948c3e435cda33d5_5.png) 

启动成功后会有一个字符界面，提示连接的端口号是：6379，请不要关闭该服务器，等待客户端连接；这里也可以把redis作成windows服务，不过redis多数情况会在linux平台使用。

## 2.4、启动客户端

再用cmd开启一个命令容器，输入命令：redis-cli -h 127.0.0.1 -p 6379，执行成功后如下所示：

![6png](https://raw.githubusercontent.com/zxniuniu/solo_backup/master/377b64add35d4d5cbe1373054efc67af_6.png) 

-h用于指定服务器位置，-p用于指定端口号；如果想改变该内容可以修改.conf文件。

## 2.5、测试并运行

![7png](https://raw.githubusercontent.com/zxniuniu/solo_backup/master/dfc513acca084af6b0943c542ff5cd4d_7.png) 

添加数据：set   

获得数据：get 

是否存在：exists 

删除数据：del 

修改数据：set  

帮助命令：help <命令名称>

![8png](https://raw.githubusercontent.com/zxniuniu/solo_backup/master/3037b57ec0134364beca639038d9f1a4_8.png) 

查找键：keys <名称能配符>

![9png](https://raw.githubusercontent.com/zxniuniu/solo_backup/master/e5921335cff743c2990ed7f9010e566b_9.png) 


设置过期时间：expire  <秒数>

![10png](https://raw.githubusercontent.com/zxniuniu/solo_backup/master/55b34b03dab7436fb58ca201e1c41954_10.png) 

删除过期时间：persist 

**info**
服务器基本信息

**monitor**

实时转储收到的请求

**config get   ????**
获取服务器的参数配置

**flushdb**
清空当前数据库

**flushall**
清除所有数据库

![11png](https://raw.githubusercontent.com/zxniuniu/solo_backup/master/de9c20308ce44e0082f0a9cb3a116a20_11.png) 


 更多命令：http://doc.redisfans.com/

## 三、常用命令
```
    1）连接操作命令
    quit：关闭连接（connection）
    auth：简单密码认证
    help cmd： 查看cmd帮助，例如：help quit
```
```
    2）持久化
    save：将数据同步保存到磁盘
    bgsave：将数据异步保存到磁盘
    lastsave：返回上次成功将数据保存到磁盘的Unix时戳
    shundown：将数据同步保存到磁盘，然后关闭服务
```
```
    3）远程服务控制
    info：提供服务器的信息和统计
    monitor：实时转储收到的请求
    slaveof：改变复制策略设置
    config：在运行时配置Redis服务器
```
```
    4）对value操作的命令
    exists(key)：确认一个key是否存在
    del(key)：删除一个key
    type(key)：返回值的类型
    keys(pattern)：返回满足给定pattern的所有key
    randomkey：随机返回key空间的一个
    keyrename(oldname, newname)：重命名key
    dbsize：返回当前数据库中key的数目
    expire：设定一个key的活动时间（s）
    ttl：获得一个key的活动时间
    select(index)：按索引查询
    move(key, dbindex)：移动当前数据库中的key到dbindex数据库
    flushdb：删除当前选择数据库中的所有key
    flushall：删除所有数据库中的所有key
```
```
    5）String
    set(key, value)：给数据库中名称为key的string赋予值value
    get(key)：返回数据库中名称为key的string的value
    getset(key, value)：给名称为key的string赋予上一次的value
    mget(key1, key2,…, key N)：返回库中多个string的value
    setnx(key, value)：添加string，名称为key，值为value
    setex(key, time, value)：向库中添加string，设定过期时间time
    mset(key N, value N)：批量设置多个string的值
    msetnx(key N, value N)：如果所有名称为key i的string都不存在
    incr(key)：名称为key的string增1操作
    incrby(key, integer)：名称为key的string增加integer
    decr(key)：名称为key的string减1操作
    decrby(key, integer)：名称为key的string减少integer
    append(key, value)：名称为key的string的值附加value
    substr(key, start, end)：返回名称为key的string的value的子串
```
```
    6）List 
    rpush(key, value)：在名称为key的list尾添加一个值为value的元素
    lpush(key, value)：在名称为key的list头添加一个值为value的 元素
    llen(key)：返回名称为key的list的长度
    lrange(key, start, end)：返回名称为key的list中start至end之间的元素
    ltrim(key, start, end)：截取名称为key的list
    lindex(key, index)：返回名称为key的list中index位置的元素
    lset(key, index, value)：给名称为key的list中index位置的元素赋值
    lrem(key, count, value)：删除count个key的list中值为value的元素
    lpop(key)：返回并删除名称为key的list中的首元素
    rpop(key)：返回并删除名称为key的list中的尾元素
    blpop(key1, key2,… key N, timeout)：lpop命令的block版本。
    brpop(key1, key2,… key N, timeout)：rpop的block版本。
    rpoplpush(srckey, dstkey)：返回并删除名称为srckey的list的尾元素，并将该元素添加到名称为dstkey的list的头部
```
```
    7）Setsadd(key, member)：向名称为key的set中添加元素member
    srem(key, member) ：删除名称为key的set中的元素member
    spop(key) ：随机返回并删除名称为key的set中一个元素
    smove(srckey, dstkey, member) ：移到集合元素
    scard(key) ：返回名称为key的set的基数
    sismember(key, member) ：member是否是名称为key的set的元素
    sinter(key1, key2,…key N) ：求交集
    sinterstore(dstkey, (keys)) ：求交集并将交集保存到dstkey的集合
    sunion(key1, (keys)) ：求并集
    sunionstore(dstkey, (keys)) ：求并集并将并集保存到dstkey的集合
    sdiff(key1, (keys)) ：求差集
    sdiffstore(dstkey, (keys)) ：求差集并将差集保存到dstkey的集合
    smembers(key) ：返回名称为key的set的所有元素
    srandmember(key) ：随机返回名称为key的set的一个元素8）Hash
    hset(key, field, value)：向名称为key的hash中添加元素field
    hget(key, field)：返回名称为key的hash中field对应的value
    hmget(key, (fields))：返回名称为key的hash中field i对应的value
    hmset(key, (fields))：向名称为key的hash中添加元素field 
    hincrby(key, field, integer)：将名称为key的hash中field的value增加integer
    hexists(key, field)：名称为key的hash中是否存在键为field的域
    hdel(key, field)：删除名称为key的hash中键为field的域
    hlen(key)：返回名称为key的hash中元素个数
    hkeys(key)：返回名称为key的hash中所有键
    hvals(key)：返回名称为key的hash中所有键对应的value
    hgetall(key)：返回名称为key的hash中所有的键（field）及其对应的value
```
## 2.6、添加windows服务

如果不添加windows服务，redis-server.exe程序一直要以GUI的形式开启在任务栏，有时候不小心会被关闭，其实也可以像其它数据库如Oracle一样将redis做成一个服务，以服务的形式运行，注册服务的方法如下：

2.6.1、在命令模式下切换到redis安装目录

2.6.2、执行指令如下命令：
```
redis-server --service-install redis.windows.conf --loglevel verbose  --service-name Redis
```
解释：
```
--service-install redis.windows.conf 指定redis配置文件

--loglevel verbose  指定日志级别

--service-name Redis 指定服务名称
```
运行命令后的结果：

![12png](https://raw.githubusercontent.com/zxniuniu/solo_backup/master/9754d57fca9f4aafb3489a700977e340_12.png) 


# 三、使用Jedis访问Redis数据库

Jedis是redis的java版的客户端实现，在java程序中我们可以通过Jedis访问Redis数据库，源代码地址（https://github.com/xetorthio/jedis），实现访问的方法如下：

## 3.1、引用或依赖Jedis包

3.1.1、如果使用Maven，修改pom.xml文件，添加Jedis的依赖，修改后的pom.xml文件如下，引用成功后的结果：

![13png](https://raw.githubusercontent.com/zxniuniu/solo_backup/master/409d7801499043c7b859f4dac1e4580b_13.png) 


从引用的结果可以发现jedis使用了commons的连接池技术。

3.1.2、如果直接添加引用，可以去github下载jedis源码包自行编译，下载地址是：[https://github.com/xetorthio/jedis/releases](https://github.com/xetorthio/jedis/releases)，当前最新版本2.8.1。

![14png](https://raw.githubusercontent.com/zxniuniu/solo_backup/master/feb1cb5f3f4d4b92a19152b721535f77_14.png) 


如果想直接下载jar包，可以到Maven共享资源库（http://search.maven.org/）下载，如下所示：

![15png](https://raw.githubusercontent.com/zxniuniu/solo_backup/master/4a01fcbc89bd480ea0c58d7fe5bed392_15.png) 

## 3.2、调用Jedis

先开启redis数据库服务，处理监听状态，在java项目中编写如下测试代码：

```
package com.zhangguo.jedisdemo;
import redis.clients.jedis.Jedis;

public class HelloJedis {
    public static void main(String[] args) {
        //实例化一个jedis对象，连接到指定的服务器，指定连接端口号
        Jedis jedis = new Jedis("127.0.0.1",6379);
        //将key为message的信息写入redis数据库中
        jedis.set("message", "Hello Redis!");
        //从数据库中取出key为message的数据
        String value = jedis.get("message");
        System.out.println(value);
        //关闭连接
        jedis.close();
    }
}
```

运行结果：
![16png](https://raw.githubusercontent.com/zxniuniu/solo_backup/master/f8c633c36ec5464a9f1e9e3c53b0cdd0_16.png) 


