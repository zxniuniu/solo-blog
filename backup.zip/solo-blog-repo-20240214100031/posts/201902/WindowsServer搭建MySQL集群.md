title: Windows Server 搭建 MySQL集群
date: '2019-02-23 12:09:21'
updated: '2019-10-15 10:18:19'
tags: [数据库, MariaDB, 性能优化]
permalink: /articles/2019/02/23/1550894766125.html
---
最近在项目中用到了MySQL集群，所以研究了两天。下面给大家分享一下成果，先来看一张mysql集群的架构图：

![9bf6a83d6004ff7b5dc03b48e8e45247.jpg](https://img.hacpai.com/file/2019/02/9bf6a83d6004ff7b5dc03b48e8e45247-d1beecbc.jpg)

上图一共分了四层：Applications、SQL、Storage、Management。 
* Applications主要是指需要连接数据库的应用程序； 
* SQL中每一个mysqld都是一个sql节点，Applications需要通过连接sql节点来存储数据，您可以把它看成应用程序与数据库集群进行数据交换的大门 
* Storage有‘仓库’的意思，所以数据都是存在数据节点（ndbd）中的，而且每个数据节点的数据都是一致的，都是一整套最新的数据 
* Management中就是管理节点，一个MySQL中只有一个管理节点，用来管理其他节点

综上所述，一个MySQL集群中包括三种节点（不包括Applications）：管理节点、数据节点，sql节点。

## 下载集群版Mysql

下载mysql-cluster-gpl-7.3.7-win32或mysql-cluster-gpl-7.4.7-winx64
![20141228110118295.png](https://img.hacpai.com/file/2019/02/20141228110118295-e46a4828.png)

本人使用的MySQL Cluster版本为：mysql-cluster-gpl-7.3.7-winx64.zip），请注意下载合适的MySQL版本，包括平台和安装方式，推荐下载zip版本，便于配置和迁移。

## 配置MySQL集群
需要用三台机器，一台配置管理节点：另外两台每台配置一个数据节点和一个SQL节点（也可以用五台计算机，每台计算机配置一个节点）： 

* 管理节点：192.168.25.50 
* 数据节点A：192.168.25.49 
* 数据节点B：192.168.25.48 
* SQL节点A：192.168.25.49 
* SQL节点B：192.168.25.48

### 首先将下载压缩包解压到每台电脑的C:/mysql目录下：
![20150814175517273.png](https://img.hacpai.com/file/2019/02/20150814175517273-6db0244a.png)

### 配置管理节点
在配置管理节点（192.168.25.50）的计算机上的C:\mysql\（**`网上很多文章均说必须放在C盘下，经本人测试，其它可以放在任意位置，如D:/cluster等，均是没有问题的`**）目录下建立cluster文件夹,在cluster中建立logs文件夹用来存储日志文件，在cluster中建立data文件夹，以及在cluster文件夹中建立my.ini和config.ini两个配置文件：

my.ini
```
[mysql_cluster] 
# Options for management node process 
config-file=C:/mysql/cluster/config.ini
```

config.ini
```
[ndbd default] 
# Options affecting ndbd processes on all data nodes: 
NoOfReplicas=2           # Number of replicas 
DataDir=C:/mysql/cluster/data   # Directory for each data node's data files 
                                    # Forward slashes used in directory path, 
                                    # rather than backslashes. This is correct; 
                                    # see Important note in text 

DataMemory=80M      # Memory allocated to data storage 
IndexMemory=18M     # Memory allocated to index storage 
                                    # For DataMemory and IndexMemory, we have used the 
                                    # default values. Since the "world" database takes up 
                                    # only about 500KB, this should be more than enough for 
                                    # this example Cluster setup.

[ndb_mgmd] 
# Management process options: 
HostName=192.168.25.50              # Hostname or IP address of management node 
DataDir=C:/mysql/cluster/data # Directory for management node log files

[ndbd] 
# Options for data node "A":     
HostName=192.168.25.49              # Hostname or IP address

[ndbd] 
# Options for data node "B":
HostName=192.168.25.48              # Hostname or IP address

[mysqld] 
# SQL node A options:
HostName=192.168.25.49              # Hostname or IP address

[mysqld] 
# SQL node B options:
HostName=192.168.25.48              # Hostname or IP address
```

### 配置数据节点

在配置数据节点（192.168.25.48、192.168.25.49）的计算机上的C:\mysql\cluster\目录下建立config文件夹，其下建立data-config.ini：

data-config.ini
```
[mysql_cluster]

# Options for data node process:
ndb-connectstring=172.16.220.10
```

### 安装SQL节点
SQL节点不用任何配置，至此，整个MySQL集群就搭建完成了。

## 启动MySQL集群
启动MySQL集群时，有一个启动顺序：`先启动管理节点`，`再启动数据节点`，`最后启动SQL节点`。

### 启动管理节点：
在cmd中运行如下命令

```
c:\mysql\bin\ndb_mgmd.exe --configdir=c:\mysql\cluster\ --config-file=c:\mysql\cluster\config.ini
```
![20150814181544140.png](https://img.hacpai.com/file/2019/02/20150814181544140-61c21485.png)

### 启动每个数据节点：
在cmd中运行如下命令：

```
c:\mysql\bin\ndbd.exe --ndb-connectstring=192.168.25.50
```
![20150814181714367.png](https://img.hacpai.com/file/2019/02/20150814181714367-7dfb14da.png)


### 启动每个sql节点：
在cmd中运行如下命令：

```
c:\mysql\bin\mysqld.exe --ndbcluster --ndb-connectstring=192.168.25.50 --console
```
![20150814190400463.png](https://img.hacpai.com/file/2019/02/20150814190400463-688ead22.png)

或者修改Mysql启动时使用的my.ini文件，位于C:/mysql下，在[mysqld]部分增加：

```
ndbcluster

ndb-connectstring=192.168.25.50
```

 如下的my.ini，注意此my.ini是MySQL的启动时使用的配置文件，不是上文c:\mysql\cluster\my.ini，此ini在`ndb_mgmd.exe` 启动管理节点时的`--configdir=c:\mysql\cluster\ `时已使用。

```
[client]

#password	= your_password
port		= 3326
socket		= /tmp/mysql.sock

# Here follows entries for some specific programs

# The MySQL server
[mysqld]
# Options for mysqld process:
ndbcluster
ndb-connectstring=192.168.25.50

port		= 3326
socket		= /tmp/mysql.sock
.
```
现在整个MySQL集群就已经启动了。

当然，你也可以注册Mysql服务，以便自动启动。注册成功在 windows 的服务里面多了一个 MySQL 的服务 (若服务已存在，请删除 mysqld--remove mysql)，
以下命令必须以管理员身份运行。
```
mysqld --initialize-insecure : 自动生成无密码的root用户；
mysqld --initialize : 是自动生成随机密码用户；
```
![1137305.jpg](https://img.hacpai.com/file/2019/02/1137305-2ac7034f.jpg)

### 查看每个节点的状态：
在管理节点所在计算机上（192.168.25.50）打开`ndb_mgm.exe`，或者直接在cmd中运行

```
c:\mysql\bin\ndb_mgm.exe
```
执行`show`命令，可以查看到每个节点的连接状态：
![20150814191113552.png](https://img.hacpai.com/file/2019/02/20150814191113552-b44b8403.png)

这就表明每个节点均连接正常。下面测试数据。

## 测试MySQL集群
### 在sql节点A建立数据库并插入数据：
在sql节点A的计算机上（192.168.25.49）的cmd中运行C:\mysql\bin\mysql.exe -u root -p命令登录mysql，接下来需要输入密码时，密码默认为空（直接回车）。

* 输入以下命令，为root用户分配远程连接的相关权限
```
GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIEDBY 'root' WITH GRANT OPTION;
```
![20141228141143865.png](https://img.hacpai.com/file/2019/02/20141228141143865-40b01811.png)

* 创建数据库并插入数据，创建名为”MySQL_Cluster_Test”的数据库：
```
 create database MySQL_Cluster_Test;
```
* 创建表”T_User”：
```
use MySQL_Cluster_Test;
create table T_User(Name varchar(32),Age int) engine=ndbcluster;
```
注意建表语句后面一定要加上`engine=ndbcluster`

* 插入数据：
```
insert into T_User values('DannyHoo',26);
```

* 查询数据：
```
selec t Name, Age from T_User;
```

![20150814192614323.png](https://img.hacpai.com/file/2019/02/20150814192614323-2e838717.png)

### 在sql节点B也可以查询到数据
同样在sql节点B的计算机上（192.168.25.48）的cmd中运行C:\mysql\bin\mysql.exe -u root -p命令登录mysql，执行 `show databases; `命令可以查看到在sql节点A新建的数据库； 执行

```
use MySQL_Cluster_Test; 
selec t Name, Age from T_User; 
```

可以查询到在sql节点A插入的数据。

![20150814192758067.png](https://img.hacpai.com/file/2019/02/20150814192758067-6f1a87d2.png)

到这里，整个集群的搭建和测试就完成了。假如一个数据节点宕机，并不会影响整个集群的运行，任何一个数据节点死掉甚至物理损坏都不用担心，因为每个数据节点保存的数据都是完整的一份数据（在你操作数据的时候，它早就自动为你把最新的数据备份到每一个数据节点上啦）。

你可以测试一下，这时手动停止某个数据节点和sql节点，另外一个数据节点和sql节点还会正常运行。当你把停止的数据节点和sql节点重新启动时，会发现又重新连接到集群里了，而且每个数据节点的数据都是最新的。
