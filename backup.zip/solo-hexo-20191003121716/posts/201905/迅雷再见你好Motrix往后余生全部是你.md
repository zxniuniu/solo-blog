title: 迅雷再见！你好，Motrix，往后余生，全部是你
date: '2019-05-22 18:36:38'
updated: '2019-05-22 18:43:31'
tags: [爬虫]
permalink: /articles/2019/05/22/1558521398548.html
---
迅雷再见！你好，Motrix，往后余生，全部是你。么错，你么有看错，目前已经和迅雷说再见了，弃坑了，不玩了。

### Motrix官方下载

* 官方网站：[https://motrix.app/](https://motrix.app/)
* 下载地址：[https://motrix.app/release/](https://motrix.app/release/)
* 使用手册：[https://www.yuque.com/moapp/help/issues](https://www.yuque.com/moapp/help/issues)

上面那个是官方下载地址

Windows：[Motrix-1.3.8-win.zip](https://github.com/agalwood/Motrix/releases/download/v1.3.8/Motrix-1.3.8-win.zip)

MAC：[Motrix-1.3.8-mac.zip](https://github.com/agalwood/Motrix/releases/download/v1.3.8/Motrix-1.3.8-mac.zip)

Linux：[Motrix-1.3.8-x86_64.AppImage](https://github.com/agalwood/Motrix/releases/download/v1.3.8/Motrix-1.3.8-x86_64.AppImage)

浏览器插件：[https://motrix.app/release/BaiduExporter.zip](https://motrix.app/release/BaiduExporter.zip)

mac 推荐使用 brew 安装

> `brew update && brew cask install motrix`

![Motrix.png](https://img.hacpai.com/file/2019/05/Motrix-6300558a.png?imageView2/0/w/240/h/240/interlace/1/q/100)

下载软件有很多选择，异次元就介绍过 IDM、Folx、Photon、FDM、迅雷等等，一数一大堆。不过正所谓各花入个眼，还是有很多人想寻找不一样的下载工具。

**Motrix** 是一款开源免费且界面非常清爽简约的全能型下载软件，它跨平台支持 Windows、Mac、Linux 三大系统，可以支持下载 HTTP、FTP、BT、磁力链接以及下载百度网盘等资源。如果你用腻了其他工具，不妨试试 Motrix 吧…


![1550152137686.png](https://img.hacpai.com/file/2019/05/1550152137686-fb657bda.png)

与大多数同类工具基本一致，Motrix 也是采用了「**Aria 2**」作为核心，所以下载速度、多线程等能力与其他工具几乎一致。

软件代码基于 Electron + Vue + VueX + Element 等技术编写而来，对开发感兴趣的同学可以参考学习一下。

Motrix 比较方便的一点是可支持百度网盘下载，它提供了「百度网盘助手」的 Chrome 浏览器扩展，可以让你通过 Motrix 直接高速下载百度网盘的资源。

### Motrix安装

MO现已更名为 Motrix，请访问官网或者Github获取最新版本；或者您也可以克隆 GitHub 上最新的源码自行编译打包。

### Motrix常见问题

2.1 RPC添加下载任务 Motrix 默认开放的 RPC 端口是 16800，暂时不支持修改。如果与其他应用的端口冲突，请避免同时使用，不然可能会无法正常使用 Motrix。

2.2 寻求帮助 如果你对于 Motrix 的使用体验不满意或者有什么疑难问题，请到[GitHub](https://github.com/agalwood/Motrix)提交[issue](https://github.com/agalwood/Motrix/issues)。

### Motrix浏览器扩展

百度网盘助手 基于开源的Chrome浏览器扩展[BaiduExporter](https://github.com/agalwood/BaiduExporter)构建，添加了 MO 2.0 相关的配置，下载地址如下：[https://motrix.app/release/BaiduExporter.zip](https://motrix.app/release/BaiduExporter.zip)

#### 1.BaiduExporter安装方法

下载 BaiduExporter.zip 之后，请解压到你喜欢的目录位置（以 ~/Documents 为例），解压到 ~/Documents/BaiduExporter 备用。

1.  启动你的 Google Chrome，点击顶部菜单栏的「扩展程序」进入扩展程序管理页面；或者直接在地址栏输入 chrome://extensions/
    
2.  点击右上角的「开发者模式」开关启用开发者模式
    
3.  点击「加载已解压的扩展程序」，弹出目录选择框选择弹层，选择前面解压出来的 ~/Documents/BaiduExporter 目录。
    
4.  确定之后，Google Chrome 会弹出桌面通知告诉你安装成功了。
    
5.  打开[百度网盘网页版](https://pan.baidu.com/)，如果页面弹出“初始化成功！”的提示，并且在你的百度网盘网页版界面上还会出现一个「MO.app」的按钮，就说明浏览器扩展安装成功了。
    

#### 2.Motrix使用方法

不保证可用性和下载速度，除非购买百度网盘SVIP，否则使用第三方工具都有被百度限速的可能性: ( 可能的解决方法：更换IP（重启宽带 or 光猫），切换百度云盘账号

注：由于百度网盘限制，请登陆百度帐号之后再下载度盘资源，不然肯定下载失败！如果是下载他人分享的文件，建议先“保存到网盘”之后再下载，不然提交任务到 Motrix 下载时会造成文件名截断

2019/02/19 更新，如果你碰到了文件名截断问题，请尝试重新下载和安装 BaiduExporter

### MO.app 按钮出现慢的问题

打开百度云盘页面时，请求这个域下的两个资源很慢，会阻塞页面，造成 MO.app 的出现也变慢。可以通过修改系统 hosts 加入以下规则屏蔽它：

> 127.0.0.1 nj.baidupcs.com


![迅雷再见！你好，Motrix，往后余生，全部是你](https://img.hacpai.com/file/2019/05/1543747019076-ca5157bc.png)

选择你要下载的文件

![迅雷再见！你好，Motrix，往后余生，全部是你](https://img.hacpai.com/file/2019/05/1543898976024-7674bcf0.png)

移动鼠标指针到「MO.app」展开下拉菜单，选择「使用MO下载」

![迅雷再见！你好，Motrix，往后余生，全部是你](https://img.hacpai.com/file/2019/05/1543747149902-1f342bea.png)

提交下载成功

![迅雷再见！你好，Motrix，往后余生，全部是你](https://img.hacpai.com/file/2019/05/1543747285866-fa98dda2.png)

如果你还没有启动MO.app，可以先点击「启动MO」来启动 Motrix

![迅雷再见！你好，Motrix，往后余生，全部是你](https://img.hacpai.com/file/2019/05/1543747223380-0f4d0524.png)

拦截 Chrome 普通下载任务

推荐安装[YAAW for Chrome](https://chrome.google.com/webstore/detail/yaaw-for-chrome/dennnbdlpgjgbcjfgaohdahloollfgoc)，安装完成之后修改配置如下： chrome://extensions/?id=eehlmkfpnagoieibahhcghphdbjcdmen

Save之后，你的 Chrome 右键菜单里就有「使用 Motrix 下载」了！ 当然你也可以设置一下文件尺寸大于xx M 拦截下载到 Motrix

![迅雷再见！你好，Motrix，往后余生，全部是你](https://img.hacpai.com/file/2019/05/1550978559175-cd105193.png)

### Motrix特征

*   简单明了的用户界面
*   支持BitTorrent和Magnet
*   支持下载百度网盘
*   最多同时下载10个任务
*   单任务最大支持64线程下载
*   模拟用户代理
*   下载完成的通知
*   准备触摸条（仅适用于Mac）
*   删除任务时删除相关文件（可选）
*   目前提供简体中文和英文版
*   ......
*   开发中的更多功能

注：macOS 和 Linux 版本使用的是 64 位的 aria2c，Windows 版使用的 32 位的）

感谢原作者，博客转自：https://www.i5seo.com/motrix-download.html