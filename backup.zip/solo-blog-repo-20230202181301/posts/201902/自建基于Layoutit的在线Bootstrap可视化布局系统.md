title: 自建基于 Layoutit 的在线 Bootstrap 可视化布局系统
date: '2019-02-25 11:22:21'
updated: '2019-10-15 10:18:36'
tags: [可视化, 工具]
permalink: /articles/2019/02/25/1551064941317.html
---
Layoutit是一个在线工具，它可以简单而又快速搭建Bootstrap响应式布局，操作基本是使用拖动方式来完成，很简单，而元素都是基于Bootstrap框架集成的， 所以这工具很适合Web设计师和前端开发人员使用，快捷方便。

**# 自建地址，欢迎使用：https://fuyiyi.imdo.co/layoutit/index.html**>

![layoutit.png](https://img.hacpai.com/file/2019/02/layoutit-9f020dca.png)

layoutit通过使用拖放界面生成器帮助您简单快速地创建Bootstrap前端代码。它列出了Bootstrap的每个元素和组件，你只需要用鼠标拖曳到页面上即完成设计，让您的前端编码更容易，不需要你是Javascript，HTML5或CSS3的专家。所有的设计可以是响应式的CSS和流体。设计完成后，您只需下载HTML即获得自己设计的源码。

如上图，layoutit有四个主要菜单：
* 布局设置，布局Layout方面，是你首先必须选择的，是单栏或左右分栏等
* 基本CSS
* 工具组件
* Javascript

![layoutit.png](https://img.hacpai.com/file/2019/02/layoutit-6bf8e505.png)

当你熟悉该工具以后，编写一个现代Html页面如同在Word里编辑文档一样方便容易。

代码地址：https://github.com/zxniuniu/layoutit
