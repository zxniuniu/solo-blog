title: 基于 KMS 服务的 Windows、Office 激活
date: '2019-07-18 21:22:43'
updated: '2019-10-15 10:24:31'
tags: [加密安全, 工具]
permalink: /articles/2019/07/18/1563456163229.html
---
KMS 在 Windows Vista 之后被引入 Windows 中，全称 Key Management Service，优点是仅需一个 KMS Key，即可激活，缺点是需要保持联网，如一段时间无法链接到 KMS 服务器，就会丧失激活。

![](https://img.hacpai.com/bing/20181028.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 使用教程
在这里使用 Windows 10 系统演示，其它系统大同小异，需要注意的是 Windows 7 旗舰版不支持KMS激活，请另行Google

### Windows激活
管理员身份运行CMD，输入以下命令，KMS Key 可在文末获得
```
slmgr /ipk 'KMS Key'
slmge /skms kms.asuhu.com
slmgr /ato
```
![kms.png](https://img.hacpai.com/file/2019/07/kms-1eb27506.png)

### Office激活
```
cd /d "C:\Program Files\Microsoft Office\Office16"
cscript ospp.vbs /sethst:kms.asuhu.com
cscript ospp.vbs /act
```
![Office2016kms.png](https://img.hacpai.com/file/2019/07/Office2016kms-9869a5c4.png)

## 附录KMS Key

#### Windows 10
|类型 |KEY |
|--- |--- |
|Windows 10 Home(家庭版) |TX9XD-98N7V-6WMQ6-BX7FG-H8Q99|
|Windows 10 Education(教育版)|NW6C2-QMPVW-D7KKK-3GKT6-VCFB2|
|Windows 10 Pro(专业版)|W269N-WFGWX-YVC9B-4J6C9-T83GX|
|Windows 10 ProWorkstation(专业工作站版)|NRG8B-VKK3Q-CXVCJ-9G2XF-6Q84J|
|Windows 10 Enterprise|NPPR9-FWDCX-D2C8J-H872K-2YT43|
|Windows 10 Enterprise LTSB 2015|WNMTR-4C88C-JK8YV-HQ7T2-76DF9|
|Windows 10 Enterprise LTSB 2016|DCPHK-NFMTC-H88MJ-PFHPY-QJ4BJ|
|Windows 10 Enterprise LTSC 2019|M7XTQ-FN8P6-TTKYV-9D4CC-J462D|
|Windows 10 Pro Education|6TP4R-GNPTD-KYYHQ-7B7DP-J447Y|
|Windows 10 Core|33QT6-RCNYF-DXB4F-DGP7B-7MHX9|
 
#### Windows 7
|类型 |KEY |
|--- |--- |
|Windows 7 Pro(专业版)|FJ82H-XT6CR-J8D7P-XQJJ2-GPDD4|
|Windows 7 Enterprise(企业版)|33PXH-7Y6KF-2VJC9-XBBR8-HVTHH|
|Windows 7 Embedded ThinPC|73KQT-CD9G6-K7TQG-66MRP-CQ22C|
|Windows 7 Embedded Standard|XGY72-BRBBT-FF8MH-2GG8H-W7KCW|
 
#### Windows 8.1
|类型 |KEY |
|--- |--- |
|Windows 8.1 Pro(专业版)|GCRJD-8NW9H-F2CDX-CCM8D-9D6T9|
|Windows 8.1 Enterprise(企业版)|MHF9N-XY6XB-WVXMC-BTDCT-MKKG7|
|Windows 8.1 ProStu(专业学生版)|MX3RK-9HNGX-K3QKC-6PJ3F-W8D7B|
|Windows 8.1 Embedded Pro|NMMPB-38DD4-R2823-62W8D-VXKJB|
|Windows 8.1 Embedded Enterprise|FNFKF-PWTVT-9RC8H-32HB2-JB34X|
|Windows 8.1 Core|M9Q9P-WNJJT-6PXPY-DWX8H-6XWKK|
 
#### Windows 8
|类型 |KEY |
|--- |--- |
|Windows 8 Pro(专业版)|NG4HW-VH26C-733KW-K6F98-J8CK4|
|Windows 8 Enterprise(企业版)|32JNW-9KQ84-P47T8-D8GGY-CWCK7|
|Windows 8 Embedded Pro|JVPDN-TBWJW-PD94V-QYKJ2-KWYQM|
|Windows 8 Embedded Enterprise |NKB3R-R2F8T-3XCDP-7Q2KW-XWYQ2|
|Windows 8 Core|BN3D2-R7TKB-3YPBD-8DRP2-27GG4|
 
#### Windows Vista
|类型 |KEY |
|--- |--- |
|Windows Vista Bussiness|YFKBB-PQJJV-G996G-VWGXY-2V3X8|
|Windows Vista Enterprise|VKK3X-68KWM-X2YGT-QR4M6-4BWMV|
 
#### Windows Server 2019
|类型 |KEY |
|--- |--- |
|Windows Server 2019 Standard|N69G4-B89J2-4G8F4-WWYCC-J464C|
|Windows Server 2019 DataCenter|WMDGN-G9PQG-XVVXX-R3X43-63DFG|
|Windows Server 2019 Essentials|WVDHN-86M7X-466P6-VHXV7-YY726|
|Windows Server 2019 DataCenter Semi-Annual Channel|6NMRW-2C8FM-D24W7-TQWMY-CWH2D|
|Windows Server 2019 Standard Semi-Annual Channel|N2KJX-J94YW-TQVFB-DG9YT-724CC|
 
#### Windows Server 2016
|类型 |KEY |
|--- |--- |
|Windows Server 2016 Standard|WC2BQ-8NRM3-FDDYY-2BFGV-KHKQY|
|Windows Server 2016 DataCenter|CB7KF-BWN84-R7R2Y-793K2-8XDDG|
|Windows Server 2016 Essentials|JCKRF-N37P4-C2D82-9YXRT-4M63B|
|Windows Server 2016 DataCenter Semi-Annual Channel v1803|2HXDN-KRXHB-GPYC7-YCKFJ-7FVDG|
|Windows Server 2016 Standard Semi-Annual Channel v1803|PTXN8-JFHJM-4WC78-MPCBR-9W4KR|
 
#### Windows Server 2012 R2
|类型 |KEY |
|--- |--- |
|Windows Server 2012 R2 Standard|D2N9P-3P6X9-2R39C-7RTCD-MDVJX|
|Windows Server 2012 R2 DataCenter|W3GGN-FT8W3-Y4M27-J84CP-Q3VJ9|
|Windows Server 2012 R2 Essentials|KNC87-3J2TX-XB4WP-VCPJV-M4FWM|
 
#### Windows Server 2012
|类型 |KEY |
|--- |--- |
|Windows Server 2012 Standard|XC9B7-NBPP2-83J2H-RHMBY-92BT4|
|Windows Server 2012 DataCenter|48HP8-DN98B-MYWDG-T2DCC-8W83P|
|Windows Server 2012 MultiPoint Standard|HM7DN-YVMH3-46JC3-XYTG7-CYQJJ|
|Windows Server 2012 MultiPoint Premium|XNH6W-2V9GX-RGJ4K-Y8X6F-QGJ2G|
 
#### Windows Server 2008 R2
|类型 |KEY |
|--- |--- |
|Windows Server 2008 R2 Web|6TPJF-RBVHG-WBW2R-86QPH-6RTM4|
|Windows Server 2008 R2 Standard|YC6KT-GKW9T-YTKYR-T4X34-R7VHC|
|Windows Server 2008 R2 Enterprise|489J6-VHDMP-X63PK-3K798-CPX3Y|
|Windows Server 2008 R2 HPC|TT8MH-CG224-D3D7Q-498W2-9QCTX|
|Windows Server 2008 R2 Datacenter|74YFP-3QFB3-KQT8W-PMXWJ-7M648|
|Windows Server 2008 R2 Itanium-based|GT63C-RJFQ3-4GMB6-BRFB9-CB83V|
 
#### Windows Server 2008
|类型 |KEY |
|--- |--- |
|Windows Server 2008 Web|WYR28-R7TFJ-3X2YQ-YCY4H-M249D|
|Windows Server 2008 Standard|TM24T-X9RMF-VWXK6-X8JC9-BFGM2|
|Windows Server 2008 Enterprise|YQGMW-MPWTJ-34KDK-48M3W-X4Q6V|
|Windows Server 2008 HPC|RCTX3-KWVHP-BR6TB-RB6DM-6X7HP|
|Windows Server 2008 Datacenter|7M67G-PC374-GR742-YH8V4-TCBY3|
|Windows Server 2008 Itanium-based|4DWFP-JF3DJ-B7DTH-78FJB-PDRHK|

参见:https://iclart.com/kms    https://kms.asuhu.com
