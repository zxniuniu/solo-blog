title: 获取Hyper-V虚拟服务器磁盘信息（供个人告警使用）
date: '2022-09-15 00:23:37'
updated: '2022-10-10 09:10:39'
tags: [加密安全, 工具]
permalink: /articles/2022/09/15/1663172617279.html
---
首先，运行命令：

```
wmic logicaldisk get * /format:list
```

找到需要的信息的名称，如需要容量信息，使用以下名称：`DeviceId`, `Size`, `FreeSpace`

修改命令行，为便于解析，去掉 `/format:list`参数

```
wmic logicaldisk get DeviceId,drivetype,Size,FreeSpace
```

发现，有DVD驱动器的，会把驱动器也列出来了，考虑排除，仅需要 `drivetype=3`的硬盘信息

```
wmic logicaldisk where drivetype=3 get DeviceId,DriveType,Size,FreeSpace
```

另外，如果需要获取远程其他服务器容量信息，可使用 `PsExec.exe`工具

```
PsExec.exe \\host -u user -p password wmic logicaldisk where drivetype=3 get DeviceId,DriveType,Size,FreeSpace
```

其他可使用的命令：

```
Get-VM * | Format-List 

Measure-VM -vmname sy222 | fl

Enable-VMResourceMetering -VMName sy222
```

留底，个人使用。

如果Hyper-V挂掉了，无法启动，可通过将VHD文件挂载到可以启动的Hyper-V虚拟机上，启动后拷贝文件。

参考：

[# windows 远程执行 cmd 命令的 9 种方法](https://cloud.tencent.com/developer/article/1487725)

[# Security with WMIC](https://docs.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2003/cc739091(v=ws.10)?redirectedfrom=MSDN)

[# 配置Hyper-V Server 资源计量](https://www.361shipin.com/blog/1514310077182377984)

[# 基本的Hyper-V PowerShell命令-程序员博客中心](https://www.361shipin.com/blog/1502174643576905730)

[# Top 10 PowerShell commands for Hyper-V](https://www.altaro.com/hyper-v/powershell-commands-hyper-v/)

[# Get-VMHardDiskDrive](https://docs.microsoft.com/en-us/powershell/module/hyper-v/get-vmharddiskdrive?view=windowsserver2022-ps)

[# 恢复Hyper-V虚拟机丢失的数据文件过程](https://developer.aliyun.com/article/111336)

