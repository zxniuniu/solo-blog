title: SS、SSR链接解析，查看对应密码、端口、协议
date: '2018-10-24 12:29:54'
updated: '2018-10-24 12:29:54'
tags: [翻墙, 爬虫, 加密, 代理]
permalink: /articles/2018/10/24/1540351937866.html
---
网上有很多人会分享一些免费的 ss/ssr 免费账号，有的会直接把服务、端口、ip、协议等展示出来（对于这种，直接手动输入相应参数就可以了），有的则直接显示二维码（二维码更方便，直接用客户端软件扫一下就可以使用）。

![](https://img.hacpai.com/bing/20180614.jpg?imageView2/1/w/960/h/520/interlace/1/q/100) 

不过，也有很多是直接以链接的形式展示出来，比如 ss://xxxxx 或 ssr://xxxx,对于这种链接的方式，复制链接后，然后直接使用ss 、ssr客户端软件导入链接即可。以 ssr 链接为例，假设有这么一个链接（以下的 ss ssr 链接都转载至 https://doub.io/sszhfx/）：

```
ssr://NjQuMTM3LjIwMS4yNDY6Mjk4NzphdXRoX3NoYTFfdjQ6Y2hhY2hhMjA6dGxzMS4yX3RpY2tldF9hdXRoOlpHOTFZaTVwYnk5emMzcG9abmd2S21SdmRXSXVZbWxrTDNOemVtaG1lQzhxTWprNE53Lz9yZW1hcmtzPTVweXM2TFNtNVktMzVwMmw2SWVxT21SdmRXSXVhVzh2YzNONmFHWjRMLW1Wbk9XRGotV2ZuLVdRalRwa2IzVmlMbUpwWkM5emMzcG9abmd2
```

这里使用 window 下 ssr 客户端导入，首先手动复制上面的链接，然后右键小飞机，选择 “剪贴板批量导入 ssr:// 链接”，如图：

![](https://coderschool.cn/wp-content/uploads/2017/12/ssfenxi1.png)

选择后，客户端就会自动识别链接，然后自动填充对应参数：

![](https://coderschool.cn/wp-content/uploads/2017/12/ssfenxi2.png)

不过本文不限于此，本文主要目的是想介绍 ss://xxx 及 ssr://xxx 这种链接是怎么生成的与及如何手动解析成对应的ip、端口、密码、加密方式等。下面详细介绍 [ss、ssr 链接解析](https://coderschool.cn/2498.html)过程。

其实 ss://… 及 ssr://… 这样的链接都是经过 url_safe Base64 编码生成的，就是先通过标准的 Base64 编码，然后再把编码内容中的 + 和 / 分别替换为 – 和 _ 这两个字符。这点很重要，解码的时候要进行反向替换，不然就会出错。

## ss链接

在 Base64 编码之前，ss链接的格式是这样的：

```
ss://method:password@server:port
```

也就是说，一般我们见到的链接就是 ss://Base64编码字段 ，其中 method:password@server:port 这部分被进行了 Base64 编码 。所以，假设有这样的一个 ss 链接：

```
ss://Y2hhY2hhMjA6ZG91Yi5pby9zc3poZngvKmRvdWIuYmlkL3NzemhmeC8qMjk4N0A2NC4xMzcuMjI5LjE1NDoyOTg3
```

那么以下的这部分字符串就是经过 Base64 编码生成的：

```
Y2hhY2hhMjA6ZG91Yi5pby9zc3poZngvKmRvdWIuYmlkL3NzemhmeC8qMjk4N0A2NC4xMzcuMjI5LjE1NDoyOTg3
```

那么如何解码? 在解码前，如果字符串中有包含 – 和 _ 的字符，要先分别替换为 + 和 / , 然后再通过 base64_decode 解码就行了，网上有很多 base64 编码解码工具，以这个为例 [base64编码/base64解码](https://coderschool.cn/tool/index.php/Index/base64) 为例，因为上面的那个字符串没有 – 和 _ 这两种字符，所以复制整段字符串到文本框：

[![](https://coderschool.cn/wp-content/uploads/2017/12/ssfenxi3.png)](https://coderschool.cn/wp-content/uploads/2017/12/ssfenxi3.png)

然后点击 base64解码即可：

[![](https://coderschool.cn/wp-content/uploads/2017/12/ssfenxi4.png)](https://coderschool.cn/wp-content/uploads/2017/12/ssfenxi4.png)

上面的字符串，解析出来就是（相对应的就是加密方法、密码、ip、端口）：

```
chacha20:doub.io/sszhfx/*doub.bid/sszhfx/*2987@64.137.229.154:2987
```

## ssr链接

在 Base64 编码之前，ssr 链接的格式是这样的：

```
ssr://server:port:protocol:method:obfs:password_base64/?params_base64
```

上面的链接的不同之处在于 password_base64 和 params_base64 ，顾名思义，password_base64 就是密码被 base64编码 后的字符串，而 params_base64 则是协议参数、混淆参数、备注及Group对应的参数值被 base64编码 后拼接而成的字符串。

即 params_base64为这些字段的拼接：

```
obfsparam=obfsparam_base64&protoparam=protoparam_base64&remarks=remarks_base64&group=group_base64
```

那么，假设现在有这样一个 ssr 链接：

```
ssr://NjQuMTM3LjIwMS4yNDY6Mjk4NzphdXRoX3NoYTFfdjQ6Y2hhY2hhMjA6dGxzMS4yX3RpY2tldF9hdXRoOlpHOTFZaTVwYnk5emMzcG9abmd2S21SdmRXSXVZbWxrTDNOemVtaG1lQzhxTWprNE53Lz9yZW1hcmtzPTVweXM2TFNtNVktMzVwMmw2SWVxT21SdmRXSXVhVzh2YzNONmFHWjRMLW1Wbk9XRGotV2ZuLVdRalRwa2IzVmlMbUpwWkM5emMzcG9abmd2
```

那么该部分就是被 base64 编码生成的：


```
NjQuMTM3LjIwMS4yNDY6Mjk4NzphdXRoX3NoYTFfdjQ6Y2hhY2hhMjA6dGxzMS4yX3RpY2tldF9hdXRoOlpHOTFZaTVwYnk5emMzcG9abmd2S21SdmRXSXVZbWxrTDNOemVtaG1lQzhxTWprNE53Lz9yZW1hcmtzPTVweXM2TFNtNVktMzVwMmw2SWVxT21SdmRXSXVhVzh2YzNONmFHWjRMLW1Wbk9XRGotV2ZuLVdRalRwa2IzVmlMbUpwWkM5emMzcG9abmd2
```

首先检查字符该字符串是否包 – 和 _ 的字符,上面的字符串没有包含这两个字符，那么把所有内容复制到文本框进行解码：

[![](https://coderschool.cn/wp-content/uploads/2017/12/ssfenxi5.png)](https://coderschool.cn/wp-content/uploads/2017/12/ssfenxi5.png)

[![](https://coderschool.cn/wp-content/uploads/2017/12/ssfenxi6.png)](https://coderschool.cn/wp-content/uploads/2017/12/ssfenxi6.png)

解码后的字符串如下：

```
64.137.201.246:2987:auth_sha1_v4:chacha20:tls1.2_ticket_auth:ZG91Yi5pby9zc3poZngvKmRvdWIuYmlkL3NzemhmeC8qMjk4Nw/?remarks=5pys6LSm5Y-35p2l6IeqOmRvdWIuaW8vc3N6aGZ4L-mVnOWDj-Wfn-WQjTpkb3ViLmJpZC9zc3poZngv
```

然后再把最后 password_base64/?params_base64 这些字符串提出来分别解码：

```
ZG91Yi5pby9zc3poZngvKmRvdWIuYmlkL3NzemhmeC8qMjk4Nw/?remarks=5pys6LSm5Y-35p2l6IeqOmRvdWIuaW8vc3N6aGZ4L-mVnOWDj-Wfn-WQjTpkb3ViLmJpZC9zc3poZngv
```

解码 password_base64 ：

```
ZG91Yi5pby9zc3poZngvKmRvdWIuYmlkL3NzemhmeC8qMjk4Nw
```

[![](https://coderschool.cn/wp-content/uploads/2017/12/ssfenxi7.png)](https://coderschool.cn/wp-content/uploads/2017/12/ssfenxi7.png)

[![](https://coderschool.cn/wp-content/uploads/2017/12/ssfenxi8.png)](https://coderschool.cn/wp-content/uploads/2017/12/ssfenxi8.png)

然后解码 params_base64，因为该字段只包含 remarks ，说明其余参数都为空 ，base64_remarks 字符串如下：

```
5pys6LSm5Y-35p2l6IeqOmRvdWIuaW8vc3N6aGZ4L-mVnOWDj-Wfn-WQjTpkb3ViLmJpZC9zc3poZngv
```

上面的字符串包含 – ，所以在解码前要把 – 这个字符通通替换为 + 字符，替换后：

```
5pys6LSm5Y+35p2l6IeqOmRvdWIuaW8vc3N6aGZ4L+mVnOWDj+Wfn+WQjTpkb3ViLmJpZC9zc3poZngv
```

然后对该字符串进行解码：

[![](https://coderschool.cn/wp-content/uploads/2017/12/ssfenxi9.png)](https://coderschool.cn/wp-content/uploads/2017/12/ssfenxi9.png)

[![](https://coderschool.cn/wp-content/uploads/2017/12/ssfenxi10.png)](https://coderschool.cn/wp-content/uploads/2017/12/ssfenxi10.png)

基本就这样，不会很复杂。当然对于使用者来说，把链接直接导入客户端就好了，而对于好奇这样的链接是怎么生成的朋友来说，可以自己手动尝试一下。