title: 自建内网可用JRebel激活服务器
date: '2018-10-10 04:06:49'
updated: '2019-10-15 09:54:58'
tags: [Tomcat, Java, 工具]
permalink: /articles/2018/10/09/1539066409411.html
---
自建内网可用JRebel激活服务器，主要采用JrebelLicenseServerforJava，部署于服务器上的Tomcat中提供服务。

# 服务器地址（打开后有使用说明）：**http://niuniu.hicp.net/jrebel**

![JrebelPNG](https://raw.githubusercontent.com/zxniuniu/solo/master/2233ce58e5eb4652b2e8ade9cc9f3dd8_Jrebel.PNG) 

## 1.安装JDK6+

JDK最新版下载地址：[http://www.oracle.com/technetwork/java/javase/downloads/index.html](http://www.oracle.com/technetwork/java/javase/downloads/index.html)

JDK历史版本下载：[http://www.oracle.com/technetwork/java/javase/archive-139210.html](http://www.oracle.com/technetwork/java/javase/archive-139210.html)

添加环境变量JAVA_HOME，请Google之


## 2.安装Maven

Maven最新版下载：[http://maven.apache.org/download.cgi](http://maven.apache.org/download.cgi)

Maven历史版本下载：[http://archive.apache.org/dist/maven/maven-3/](http://archive.apache.org/dist/maven/maven-3/)


## 3.下载Jrebel License Server项目

项目地址：[https://gitee.com/gsls200808/JrebelLicenseServerforJava](https://gitee.com/gsls200808/JrebelLicenseServerforJava)

(1).zip下载方式：

打开项目地址，点击项目右侧的克隆/下载-->下载ZIP，在打开的新页面中输入验证码，即可下载zip文件

![](https://img-blog.csdn.net/20171212200521443)


(2).git方式，先安装git客户端，推荐使用git for windows

在命令行执行如下命令即可下载

```
git clone git@gitee.com:gsls200808/JrebelLicenseServerforJava.git
```

(3).启动服务器

默认端口占用8081，如果你有其它程序占用这个端口，请自行搜索8081修改为其它端口

先用cd命令切换到项目目录（zip的需要先解压）

```
cd /path/to/JrebelLicenseServerforJava
```

执行编译命令

```
mvn compile
```

指定主类运行

```
mvn exec:java -Dexec.mainClass="com.vvvtimes.server.MainServer"
```

验证服务器是否启动，浏览器打开如下网址

[http://localhost:8081/](http://localhost:8081/)

返回如下页面说明启动成功

![myjrebelPNG](https://raw.githubusercontent.com/zxniuniu/solo/master/b96c72422aeb41939f2655909d90b28d_myjrebel.PNG) 

##  4.Jrebel激活验证

Jrebel Eclipse安装参考：[https://segmentfault.com/a/1190000005746934](https://segmentfault.com/a/1190000005746934)

下载地址参考：[http://update.zeroturnaround.com/update-site-archive/update-site-7.1.0.RELEASE/](http://update.zeroturnaround.com/update-site-archive/update-site-7.1.0.RELEASE/)

激活建议参考：[http://blog.lanyus.com/archives/317.html](http://blog.lanyus.com/archives/317.html)

激活时将文中的“[http://127.0.0.1:8888/](http://127.0.0.1:8888/)”改成“[http://localhost:8081/](http://localhost:8081/)”即可

![JrebelActiPNG](https://raw.githubusercontent.com/zxniuniu/solo/master/270b718e91914dcb90562841941fcaf4_JrebelActi.PNG) 

## 5.JRebel for Android激活验证

安装参考：[http://blog.csdn.net/googdev/article/details/53288564](http://blog.csdn.net/googdev/article/details/53288564)

激活参考：[http://blog.lanyus.com/archives/299.html](http://blog.lanyus.com/archives/299.html)

激活时将文中的“[http://idea.lanyus.com/](http://idea.lanyus.com/)+ 刚才生成的GUID”改成“[http://localhost:8081/](http://localhost:8081/)+ 刚才生成的GUID”即可

激活菜单：Tools-->Jrebel for Android-->I have a license

## 6.XRebel激活验证

安装参考：[http://blog.csdn.net/u011506543/article/details/62038137?winzoom=1](http://blog.csdn.net/u011506543/article/details/62038137?winzoom=1)

新版的安装可能不需要加参数了只要放了lib

激活参考：[http://blog.lanyus.com/archives/150.html](http://blog.lanyus.com/archives/150.html)

激活时将文中的“[http://idea.lanyus.com/](http://idea.lanyus.com/)”改成“[http://localhost:8081/](http://localhost:8081/)”即可

## 7.自建服务器

# 服务器地址（打开后有使用说明）：**http://niuniu.hicp.net/jrebel**

![myjrebelPNG](https://raw.githubusercontent.com/zxniuniu/solo/master/b96c72422aeb41939f2655909d90b28d_myjrebel.PNG) 
