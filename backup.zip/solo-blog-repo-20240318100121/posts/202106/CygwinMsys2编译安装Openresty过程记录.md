title: Cygwin/Msys2 编译安装 Openresty 过程记录
date: '2021-06-09 07:53:03'
updated: '2021-06-09 09:19:26'
tags: [Nginx, 工具, 代理]
permalink: /articles/2021/06/09/1623196383353.html
---
OpenResty 的 Win32/Win64 构建目前是通过 MSYS2/MinGW 工具链构建的，包括 MinGW gcc 7.2.3、MSYS2 perl 5.24.4、MSYS2 bash、MSYS2 make 等。

![](https://b3logfile.com/bing/20180917.jpg?imageView2/1/w/1000/h/300/interlace/1/q/100)

### 采用Cygwin编译

#### 基础模块安装

下载安装Cygwin和基础模块，比如wget，lynx，perl，其他有需要安装的可以直接安装。在安装完成后，如果还需要安装模块，可采用Cygwin安装包重新添加安装包，如luajit，pcre，zlib，openssl，lua-json相关包，或在第一步中安装。另外，也可采用apt-cyg进行安装，后面就可以使用包管理器 `apt-cyg`了，然后采用  `apt-cyg install package` 进行包安装。

```
lynx -source raw.fastgit.org/transcode-open/apt-cyg/master/apt-cyg > apt-cyg
install apt-cyg /bin
```

使用安装Cygwin时的安装包，setup-x86_64.exe，在选择源后，选中要安装的模块并安装。

![image.png](https://b3logfile.com/file/2021/06/image-5979c2a9.png)

![image.png](https://b3logfile.com/file/2021/06/image-dbc51b1c.png)

#### Lua安装

下载并手工编译安装lua-5.1.5。经测试5.3好像不支持openresty-1.19.3版本。另外，需要注意：Lua默认的Makefile中没有开启动态加载模块功能，需手动修改才能编译。

下载主页：http://www.lua.org/versions.html#5.1
下载地址：http://www.lua.org/ftp/lua-5.1.5.tar.gz

修改lua源码文件下的 src/Makefile 文件找到posix修改成这样：

```
posix:
    #$(MAKE) all MYCFLAGS=-DLUA_USE_POSIX
    $(MAKE) all MYCFLAGS="-DLUA_USE_POSIX -DLUA_USE_DLOPEN" MYLIBS="-ldl"
```

然后按照readme编译安装命令：make posix 和 make install。

#### Openresty修改

下载Openresty，并编译。

下载地址：https://openresty.org/cn/download.html

修正lua的C模块编译脚本，共需修正3个文件(其实就是3个模块)，lua-cjson,lua-rds-parser,lua-redis-parser，修改基本一样，在参数后面添加 ` -L/usr/local/lib -llua`

![image.png](https://b3logfile.com/file/2021/06/image-7768a242.png)

lua-cjson:
![](https://b3logfile.com/file/2021/06/solo-fetchupload-8026588398472317988-cd40ffc1.png)

lua-rds-parser:
![](https://b3logfile.com/file/2021/06/solo-fetchupload-3872356764813195214-cac3393f.png)

lua-redis-parser:
![](https://b3logfile.com/file/2021/06/solo-fetchupload-5028830389891259360-321ded91.png)

注意以上的修改，在重新运行 `./configure` 后会被覆盖，所以做好备份。使用Cygwin编译安装太费劲了，中间会报各种错误，不推荐使用，下载是直接使用Msys2安装，一次成功。

### 采用Msys2安装

官方主页：http://mingw-w64.org/doku.php/download
下载地址：https://repo.msys2.org/distrib/x86_64/

#### Msys2安装

输入所需的**安装文件夹**（仅支持NTFS 卷上的路径，无空格，无特殊符号等路径）。然后，更新包数据库和基础包，除非安装文件是最新的，否则将需要两个步骤。第一次运行 `pacman -Syu`

```
$ pacman -Syu
:: Synchronizing package databases...
mingw32                        805.0 KiB
mingw32.sig                    438.0   B
mingw64                        807.9 KiB
mingw64.sig                    438.0   B
msys                           289.3 KiB
msys.sig                       438.0   B
:: Starting core system upgrade...
warning: terminate other MSYS2 programs before proceeding
resolving dependencies...
looking for conflicting packages...

Packages (6) bash-5.1.004-1  filesystem-2021.01-1
mintty-1~3.4.4-1  msys2-runtime-3.1.7-4
pacman-5.2.2-9  pacman-mirrors-20201208-1

Total Download Size:   11.05 MiB
Total Installed Size:  53.92 MiB
Net Upgrade Size:      -1.24 MiB

:: Proceed with installation? [Y/n]
:: Retrieving packages...
bash-5.1.004-1-x86_64            2.3 MiB
filesystem-2021.01-1-any        33.2 KiB
mintty-1~3.4.4-1-x86_64        767.2 KiB
msys2-runtime-3.1.7-4-x86_64     2.6 MiB
pacman-mirrors-20201208-1-any    3.8 KiB
pacman-5.2.2-9-x86_64            5.4 MiB
(6/6) checking keys in keyring       100%
(6/6) checking package integrity     100%
(6/6) loading package files          100%
(6/6) checking for file conflicts    100%
(6/6) checking available disk space  100%
:: Processing package changes...
(1/6) upgrading bash                 100%
(2/6) upgrading filesystem           100%
(3/6) upgrading mintty               100%
(4/6) upgrading msys2-runtime        100%
(5/6) upgrading pacman-mirrors       100%
(6/6) upgrading pacman               100%
:: To complete this update all MSYS2 processes including this terminal will be closed. Confirm to proceed [Y/n]
```

从开始菜单运行“MSYS2 MSYS”。使用以下命令更新其余基本软件包`pacman -Su`

```
$ pacman -Su
:: Starting core system upgrade...
 there is nothing to do
:: Starting full system upgrade...
resolving dependencies...
looking for conflicting packages...

Packages (20) base-2020.12-1  bsdtar-3.5.0-1
              [... more packages listed ...]

Total Download Size:   12.82 MiB
Total Installed Size:  44.25 MiB
Net Upgrade Size:       3.01 MiB

:: Proceed with installation? [Y/n]
[... downloading and installation continues ...]
```

#### Msys2工具安装

现在 MSYS2 已经安装完成，再安装一些工具和 mingw-w64 GCC 就可以使用了，运行 `pacman -S --needed base-devel mingw-w64-x86_64-toolchain`

```
$ pacman -S --needed base-devel mingw-w64-x86_64-toolchain
warning: file-5.39-2 is up to date -- skipping
[... more warnings ...]
:: There are 48 members in group base-devel:
:: Repository msys
   1) asciidoc  2) autoconf  3) autoconf2.13  4) autogen
   [... more packages listed ...]

Enter a selection (default=all):
:: There are 19 members in group mingw-w64-x86_64-toolchain:
:: Repository mingw64
   1) mingw-w64-x86_64-binutils  2) mingw-w64-x86_64-crt-git
   [... more packages listed ...]

Enter a selection (default=all):
resolving dependencies...
looking for conflicting packages...

Packages (123) docbook-xml-4.5-2  docbook-xsl-1.79.2-1
               [... more packages listed ...]
               m4-1.4.18-2  make-4.3-1  man-db-2.9.3-1
               mingw-w64-x86_64-binutils-2.35.1-3
               mingw-w64-x86_64-crt-git-9.0.0.6090.ad98746a-1
               mingw-w64-x86_64-gcc-10.2.0-6
               mingw-w64-x86_64-gcc-ada-10.2.0-6
               mingw-w64-x86_64-gcc-fortran-10.2.0-6
               mingw-w64-x86_64-gcc-libgfortran-10.2.0-6
               mingw-w64-x86_64-gcc-libs-10.2.0-6
               mingw-w64-x86_64-gcc-objc-10.2.0-6
               mingw-w64-x86_64-gdb-10.1-2
               mingw-w64-x86_64-gdb-multiarch-10.1-2
              [... more packages listed ...]

Total Download Size:    196.15 MiB
Total Installed Size:  1254.96 MiB

:: Proceed with installation? [Y/n]
[... downloading and installation continues ...]
```

要使用 mingw-w64 GCC 开始构建，请关闭此窗口并从“开始”菜单运行“MSYS MinGW 64 位”，就可以调用`make`或`gcc`构建软件了。

### 构建Openresty

将下载的Openresty，放入Msys2安装目录下的 `/usr/local/` 文件夹下，在打开的 `MSYS MinGW 64 位`窗口中，运行：

```
cd /usr/local/openresty-1.19.3.2
wget https://www.openssl.org/source/openssl-1.1.1k.tar.gz
wget http://zlib.net/zlib-1.2.11.tar.gz
wget https://ftp.pcre.org/pub/pcre/pcre-8.44.tar.gz
```

完成OpenSSL、Zlib 和 PCRE 的依赖库的下载，下面开始编译：

```
#!/bin/bash

PCRE=pcre-8.44
ZLIB=zlib-1.2.11
OPENSSL=openssl-1.1.1k
JOBS=8

# wget https://www.openssl.org/source/openssl-1.1.1g.tar.gz
# wget http://zlib.net/zlib-1.2.11.tar.gz
# wget https://ftp.pcre.org/pub/pcre/pcre-8.44.tar.gz

rm -rf objs || exit 1
mkdir -p objs/lib || exit 1
cd objs/lib || exit 1
ls ../../..
tar -xf ../../../$OPENSSL.tar.gz || exit 1
tar -xf ../../../$ZLIB.tar.gz || exit 1
tar -xf ../../../$PCRE.tar.gz || exit 1
cd ../..

cd objs/lib/$OPENSSL || exit 1
#patch -p1 < ../../../patches/openssl-1.1.0j-parallel_build_fix.patch || exit 1
patch -p1 < ../../../patches/openssl-1.1.1f-sess_set_get_cb_yield.patch || exit 1
#patch -p1 < ../../../patches/openssl-1.1.1d-win_fix.patch || exit 1
#patch -p1 < ../../../patches/openssl-1.1.1e-sess_set_get_cb_yield.patch || exit 1
cd ../../..

    #--with-openssl-opt="no-asm" \

./configure \
    --with-cc=gcc \
    --with-ipv6 \
    --prefix= \
    --with-cc-opt='-DFD_SETSIZE=1024' \
    --sbin-path=nginx.exe \
    --with-pcre-jit \
    --without-http_rds_json_module \
    --without-http_rds_csv_module \
    --without-lua_rds_parser \
    --with-ipv6 \
    --with-stream \
    --with-stream_ssl_module \
    --with-stream_ssl_preread_module \
    --with-http_v2_module \
    --without-mail_pop3_module \
    --without-mail_imap_module \
    --without-mail_smtp_module \
    --with-http_stub_status_module \
    --with-http_realip_module \
    --with-http_addition_module \
    --with-http_auth_request_module \
    --with-http_secure_link_module \
    --with-http_random_index_module \
    --with-http_gzip_static_module \
    --with-http_sub_module \
    --with-http_dav_module \
    --with-http_flv_module \
    --with-http_mp4_module \
    --with-http_gunzip_module \
    --with-select_module \
    --with-luajit-xcflags="-DLUAJIT_NUMMODE=2 -DLUAJIT_ENABLE_LUA52COMPAT" \
    --with-pcre=objs/lib/$PCRE \
    --with-zlib=objs/lib/$ZLIB \
    --with-openssl=objs/lib/$OPENSSL \
    --with-pcre-jit \
    --with-mail \
    --with-mail_ssl_module \
    -j$JOBS || exit 1

make -j$JOBS || exit 1
make install
```

或直接采用util目录下的 `build-win32.sh` 文件，将其复制到openresty根目录，然后运行。

参见：

[记录自己cygwin上编译安装openresty的过程](https://www.geek-share.com/detail/2684030840.html)

[Cygwin上编openresty终于折腾出来了，发个patch，春哥看看能不能整合进去](https://forum.openresty.us/d/1897-e780e69d9188f78e3fa52384bf7ae276)

[Msys2安装教程](https://www.msys2.org/#installation)

[Details About Openresty's Building Process](https://github.com/openresty/openresty/blob/master/doc/README-windows.md#details-about-the-building-process)

[给已经编译安装了的nginx 添加http_ssl_module模块](https://www.huaweicloud.com/articles/859d00fe86645e0cf2b6ac8bd8ee498a.html)

[为已安装的 nginx 新增模块（以mail模块为例）](https://blog.csdn.net/ITxiaozhi/article/details/89497185)

[在已经安装好的 Openresty上增加新模块（Nginx 的新增方式也一样）](https://www.codeleading.com/article/98252251805/)

[Openresty 如何添加模块](https://my.oschina.net/u/2553994/blog/600930)

[如何对nginx Lua module添加新api](https://www.kancloud.cn/allanyu/openresty-best-practices/82655)

[在Win下编译OpenResty](http://wendal.net/2013/06/25.html)

[Openresty(动态)添加nginx模块](https://yl.frontjs.cc/2018/12/12/2018-12-12-openrestry-nginx-http2-module/)

[手动编译Openresty](https://fungit.org/2021/manually-compile-openresty/)

[Openresty 添加 proxy_cache_purge 模块 多后台代理](https://blog.wumashi.com/archives/641)

[How to install apt-cyg for Cygwin?](https://stackoverflow.com/questions/45286337/how-to-install-apt-cyg-for-cygwin)

[Install Cygwin and apt-cyg (and SSH)](https://www.ccammack.com/posts/install-cygwin-and-apt-cyg/)

[Windows下安装Cygwin及apt-cyg](https://www.jianshu.com/p/fac45920628d)

[在已编译安装nginx上动态添加模块](https://blog.csdn.net/baiqian1909/article/details/101986465?utm_medium=distribute.pc_relevant.none-task-blog-baidujs_title-9&spm=1001.2101.3001.4242)

