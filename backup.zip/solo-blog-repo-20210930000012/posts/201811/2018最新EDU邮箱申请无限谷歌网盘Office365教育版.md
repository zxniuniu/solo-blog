title: 2018最新EDU邮箱申请-无限谷歌网盘，Office365教育版
date: '2018-11-04 09:50:59'
updated: '2019-10-15 10:12:57'
tags: [工具, 性能优化]
permalink: /articles/2018/11/04/1541296167680.html
---
**无限谷歌存储空间，还能变成1EB的电脑硬盘**。首先申请edu邮箱，就可以解锁标题所有姿势。

> **先打一针，以下全程需要特殊网络，能打开谷歌那种网络。**
> 
> **过程如有问题，请留言**

first，去虚拟身份网站。[英文车](https://www.fakenamegenerator.com/) [中文车](http://www.haoweichi.com/Index/random)

[![](https://www.erbuxiu.com/wp-content/uploads/2018/04/af7a4154152bc0f7255bd7784de0ce59.png)](https://www.erbuxiu.com/wp-content/uploads/2018/04/af7a4154152bc0f7255bd7784de0ce59.png)

get一个美区虚拟身份。

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379852.jpeg)

> 注意，XXX的信息，需要登陆网站才会显示。

get信息后，去申请申请网站的账号。你没看错，申请X2。开通这个教育版账号，需要另一套申请系统的账号。 [车牌在这](https://www.opencccapply.net/uPortal/f/u66l1s1000/normal/render.uP)

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379852-1.jpeg)

需要用到你自己邮箱，尽量用谷歌邮箱，尽量用国外邮箱，QQ之类还是自己留着玩吧。

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379852-2.jpeg)

**填入虚拟的姓名。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379852-3.jpeg)

> 其他都可以选No。

**填入对应的生日。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379853.jpeg)

> 关键信息，**务必截图保存**！！！

**填入对应的SSN。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379853-1.jpeg)

> 据说也可以勾选没有SSN，不过我没试过。

**填入自己的邮箱。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379853-2.jpeg)

> Repeat，尽量用谷歌邮箱，尽量用国外邮箱。

**填入虚拟的手机号。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379853-3.jpeg)

> 填一个就行，第二个空着不用管。

**填入对应的地址。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379853-4.jpeg)

> 虚拟地址，有可能会报错。

别急，报错后，勾上最下面的选项。

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379854.jpeg)

**设置你想要的用户名和密码。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379854-1.jpeg)

> 注意，密码仅限数字和字母，不能用符号，否则报错。

**设置你想要的安全码。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379854-2.jpeg)

> 注意，安全码仅限数字，4位数字。

**设置你想要的安全问题和答案。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379854-3.jpeg)

**进行人机身份验证。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379855.jpeg)

> 这玩意是谷歌的，So，你懂的。

**验证通过后，申请网站的账号就已申请到。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379855-1.jpeg)

**开始申请教育版账号。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379855-2.jpeg)

> 框中的学校，不要选错。如图这个才是对的。

**会先哔哔一些注意事项，不用细看，直接开始。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379855-3.jpeg)

**注意，以下都是选择题，看得懂就自己选，偷懒就跟我选一样滴。**

**确认学期和专业。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379855-4.jpeg)

**确认个人信息。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379856.jpeg)

勾选下面这个就行，不用再填一遍。

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379856-1.jpeg)

**继续确认个人信息，选择性别以及。。。性取向。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379856-2.jpeg)

还要选择以下这3样。

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379856-3.jpeg)

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379857.jpeg)

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379857-1.jpeg)

**确认受教育水平。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379857-2.jpeg)

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379857-3.jpeg)

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379857-4.jpeg)

**确认公民信息。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379858.jpeg)

**确认居住信息。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379858-1.jpeg)

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379858-2.jpeg)

**确认兴趣爱好。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379858-3.jpeg)

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379859.jpeg)

**确认一些额外信息。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379859-1.jpeg)

能选不想回答的问题，就都不想回答。

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379859-2.jpeg)

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379859-3.jpeg)

**确认接受各种条款。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379860.jpeg)

**复查之前的各种选择。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379860-1.jpeg)

直接拖到下方，提交申请。

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379860-2.jpeg)

**还没完，打勾确认隐私条款。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379860-3.jpeg)

**之后，你的申请才能正式提交。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379861.jpeg)

**等3到5分钟，邮箱里会收到几封邮件，其中一封会带上你的教育ID。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379861-1.jpeg)

> 收到ID，才算是申请成功。之后，用这ID去管理系统，get教育邮箱。

**登陆[账号管理系统](https://smccis.smc.edu/smcweb/f?p=420180314:102::::::)。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379861-2.jpeg)

> 之前截图保存的信息有用了。默认密码是你最开始填写的生日信息，按月日年排布。比如我申请时用的06.17.1998，转换后就是061798。

**首次登陆，提示需要升级账号。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379861-3.jpeg)

**那就升级呗，升级前会重复一遍账号密码。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379861-4.jpeg)

**同意各种条款。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379862.jpeg)

**设置安全问题。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379862-1.jpeg)

**修改登陆密码。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379862-2.jpeg)

**再次登陆账号管理系统。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379862-3.jpeg)

**还会哔哔一堆，不用细看，挨个确认就行。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379862-4.jpeg)

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379862-5.jpeg)

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379862-6.jpeg)

**终于，特么终于进入管理系统。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379863.jpeg)

> 功能很多，基本用不上，除了邮箱的快捷入口。

**直接看页面最下方吧，才是我们需要的信息：邮箱账户名和邮箱地址。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379863-1.jpeg)

> 注意，实际使用时，不要直接复制，把大写字母换成小写才能用。

**用邮箱地址，登入谷歌邮箱**，没毛病。

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379863-2.jpeg)

**用邮箱地址，登入谷歌网盘**，也没毛病。

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379863-3.jpeg)

**看看网盘容量。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379863-4.jpeg)

仔细看几遍。

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379863-5.jpeg)

**安装谷歌官方的管理软件。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379864.jpeg)

1EB的电脑硬盘，嘿嘿。 google 虚拟云端硬盘应用→ [WINDOWS](https://g.co/GetDriveFileStream)   [MAC](https://dl.google.com/drive-file-stream/googledrivefilestream.dmg)

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379864-1.jpeg)

**这教育账号还有个小福利。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379864-2.jpeg)

**可以开通微软Office365教育版，能用在线版Office，以及微软的OneDrive网盘。**

![](https://www.erbuxiu.com/wp-content/uploads/2018/04/beepress-beepress-weixin-zhihu-jianshu-plugin-2-4-2-319-1523379864-3.jpeg

感谢原作者，博客转自：https://www.erbuxiu.com/0044295.html
