title: 开源博客Solo零基础搭建，以及Apache、Tomcat下多应用部署
date: '2018-09-09 05:33:43'
updated: '2018-10-11 07:09:54'
tags: [部署, Tomcat, Java]
permalink: /articles/2018/09/08/1536376494775.html
---
## 终于下定决心搭建一个博客，记录下日常的生活了。经过对比，还是觉得solo这个框架相对来说比较简单，同时也是对Java比较熟吧，在此感谢B3log的无私奉献。先来张张小妞的生活照吧。
![1378805150jpg](https://raw.githubusercontent.com/zxniuniu/solo/master/ab721da076804c159f678bc7e2c7705f_1378805150.jpg) 

搭建过程整体比较顺利，官方已经有比较详细的教程了，我主要修改采用了MariaDB。同时验证了以下参数的意义：

1. 如果单个项目使用一个数据库的话，可以考虑去掉local.properties中的jdbc.tablePrefix，数据库表就不需要增加prefix了；
2. 第二参数就是solo.properties中的uploadDir，如果配置相对路径，将是Tomcat（如果你使用Tomcat的话）的根目录。

## 另外，根据GitHub上的细节配置：

主要的配置文件有两个，它们都存放在 WEB-INF/classes 目录下。

*   latke.properties：用于配置域名和端口，请配置为浏览器访问时候的域名和端口，像我的服务器，Apache采用80端口，Tomcat采用8080端口，我采用了Apache的proxy模块，实现反向代理，将部署在Tomcat8080端口下的Solo映射到Apache的80端口下，从而通过内网穿透的形式进行访问。

（我是不是透漏了什么？）
![20180908_221437png](https://raw.githubusercontent.com/zxniuniu/solo/master/1541bc97204e4d24bbf074b80ce7121e_20180908_221437.png) 


*   local.properties：用于配置数据库，如果要使用 MySQL 的话请先手动建库，字符集使用 `utf8mb4`，排序规则 `utf8mb4_general_ci`。

另外，**千万不要**手动修改数据库，否则可能会引发各种莫名其妙的问题。（目前为止，注册后手动修改了几个人员为管理员，貌似未发现问题）


另外，最主要的问题是解决同一域名访问Apache及Tomcat下多个应用的问题。这个有需求了再写吧，感觉用的人应该不多。