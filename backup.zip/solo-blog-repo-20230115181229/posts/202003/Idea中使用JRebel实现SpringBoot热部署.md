title: Idea 中使用 JRebel 实现 SpringBoot 热部署
date: '2020-03-26 11:10:14'
updated: '2020-03-27 14:01:01'
tags: [Java, Springboot, 工具, 性能优化]
permalink: /articles/2020/03/26/1585192214841.html
---
在 SpringBoot 开发过程中，当 Debug 项目时，修改代码逻辑、修改接口路由、新增工具类等等情况下，一般都需要重新启动项目。通过配置 JRebel 可实现热部署，保存代码后自动编译新文件，并通过 JRebel 自动 Reload，从而实现快捷开发。

![](https://img.hacpai.com/bing/20180408.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### SpringBoot 实现热部署方式

SpringBoot 已经提供了实现热部署的方法，你只需要引入依赖**springboot-devtools**就可以了 。

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-devtools</artifactId>
</dependency>
```

添加 spring-boot-devtools 之后就可以实现热部署了，那为什么我们还需要 JRebel 呢？

* 1、 `springboot-devtools` 方式的热部署在功能上有限制，方法内的修改可以实现热部署，但新增的方法或者修改方法参数之后热部署是不生效的；
* 2、相对于 JRebel， `springboot-devtools` 方式热部署的速度可能有点慢，影响效率。

### 安装激活 JRebel

Settings → Plugins → 搜索 JRebel，然后安装，安装后重启 Idea，或者参见官方安装教程 [IntelliJ IDEA – JRebel manual](https://manuals.jrebel.com/jrebel/ide/intellij.html)

![image.png](https://img.hacpai.com/file/2020/03/image-2ee1f7de.png)

安装完成后进入 Help → JRebel → Activation 激活，具体激活请参见我以前的一篇文章 [自建内网可用JRebel激活服务器](https://fuyiyi.imdo.co/articles/2018/10/09/1539066409411.html)
如果您不想自己搭建，也可以直接打开 [http://niuniu.hicp.net/jrebel/](http://niuniu.hicp.net/jrebel/) 复制一个地址进行激活。

![image.png](https://img.hacpai.com/file/2020/03/image-3ea3f75e.png)

### 配置 Idea 打开自动编译

进入设置 Settings → Build, Execution, Deployment → Compiler，然后勾选 Build project automatically

![20200326103542.jpg](https://img.hacpai.com/file/2020/03/20200326103542-c49644b3.jpg)

由于 Build project automatically 选项仅在

Idea 主界面快捷键 ctrl+shift+alt+/，选择 Registry...，然后找到 compiler.automake.allow.when.app.running 并勾选，此时已经生效，修改代码后 ctrl+s 会自动重新编译，编译完成后 JRebel 也会自动加载新的文件。

![image.png](https://img.hacpai.com/file/2020/03/image-773ff804.png)

### 配置项目启动

首先启动项目请使用 JRebel 按钮启动。

![20200326104713.jpg](https://img.hacpai.com/file/2020/03/20200326104713-1e94b0b3.jpg)

另外：On 'Update' action: 表示按 ctrl+F10 更新项目时激活的操作；On frame deactivation: 表示切换到其它窗口后 Idea 是否启动相应操作，选择 Update classes and resources 表示离开 Idea 后会启动编译新文件

![image.png](https://img.hacpai.com/file/2020/03/image-d6388f74.png)

### 结论

Idea 确实好用，刚从 Eclipse 转过来，开始学习各种快捷键，各种 Idea 新知识，加油！

参见：[基于 SpringBoot & IDEA & JRebel 玩转远程热部署与远程调试](https://www.frankfeekr.cn/2019/07/17/springboot-idea-jrebel-hotswap/)
