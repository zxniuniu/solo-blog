title: Piwigo相册支持中文文件夹及文件名设置（备用）
date: '2022-09-26 09:21:06'
updated: '2022-09-26 09:21:55'
tags: [相册, 知识管理, 工具]
permalink: /articles/2022/09/26/1664155266137.html
---
准备升级Piwigo相册到最新的12.3版本，Dig了下，发现竟然可以设置支持中文目录，还有文件名，这简直不要太方便。

![](https://b3logfile.com/file/2022/09/solo-fetchupload-9803349982988182946-GGmv1kx.jpeg)

## 默认Piwigo 导入(同步)工具无法识别中文字符

![image.png](https://b3logfile.com/file/2022/09/image-WnnoHKK.png)

## 安装启用 `LocalFiles Editor` 插件

![image.png](https://b3logfile.com/file/2022/09/image-gIuwE0F.png)

## 设置支持中文等字符

![image.png](https://b3logfile.com/file/2022/09/image-wmcpLsg.png)

具体文本设置内容如下:

```
$conf['sync_chars_regex'] = '/^[\x{0800}-\x{9fa5}a-zA-Z0-9-_.\(\)\[\]【】（）, ★☆@#\s+]+$/u';
```

正则表达式，如果还需要其他特殊字符支持，自行添加即可。设置完成后点击下方保存即可，这样后面中文目录，以及图片或视频中有中文也可以同步了。

参考:

[Piwigo 导入(同步)工具无法正确识别中文件名问题](https://www.idzd.top/archives/302/)

[NAS开源相册piwigo的一些补充（中文名，自动同步）](https://post.smzdm.com/p/aekeg5lk/)

