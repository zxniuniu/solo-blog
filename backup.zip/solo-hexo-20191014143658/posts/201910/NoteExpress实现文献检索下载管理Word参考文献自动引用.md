title: NoteExpress 实现文献检索、下载、管理、Word参考文献自动引用
date: '2019-10-09 12:30:42'
updated: '2019-10-14 11:25:44'
tags: [工具]
permalink: /articles/2019/10/09/1570595442064.html
---
NoteExpress 是一款通用参考文献管理软件， 具有更高的管理效率， 更好地兼容中文， 更容易上手， 而且具有一些独特的创新功能以及丰富的辅助资源， 是管理和使用参考文献资料和信息的首要选择。 
最近我家那位在职论文撰写过程中需要用到文献管理，所以就把这个还是在本科及研究生时使用的好用的软件拿出来用了下，感觉是越来越好用啊，效率反正是提高了不少，你唯一需要关心的就是检索资料，以及记录需要引用的文献就可以了，参考文献生成那简直太方便了。

### NoteExpress核心功能
  
* **数据收集**：通过插件保存题录和全文到NoteExpress，可以快速下载大量题录（文摘）及全文
  
* **文献管理**：分类管理电子文献题录以及全文——海量数据、井然有序  
  
* **结果分析**：对检索结果进行多种统计分析——有的放矢，事半功倍  
  
* **主动发现**：综述阅读方式，快速发现有价值文献，与文献相互关联的笔记功能可以让您随时记录思想火花  
  
* **高效写作**：支持Word和WPS，自动生成符合要求的参考文献索引，繁琐工作，一键完成

### 下载安装
目前最新的版本为3.2版本，你可以直接Google下载或前往以下链接下载。
 
* [官网介绍](http://www.inoteexpress.com/wiki/index.php)
* [集团用户版下载](https://www.lanzous.com/i6nt80b)

下载安装可参见以详细教程: [文献检索与管理 | NoteExpress下载和安装教程](https://zhuanlan.zhihu.com/p/24909375)

![image.png](https://img.hacpai.com/file/2019/10/image-bd25b6c3.png)

### 知网检索导入
#### 1、在中国知网以关键词“GLP-1”并含“糖尿病”进行检索，结果如下。

![v2dc15f1694a8b521bfcf1c73813e3c78dhd.jpg](https://img.hacpai.com/file/2019/10/v2dc15f1694a8b521bfcf1c73813e3c78dhd-e84aa387.jpg)

#### 2、点击“题名”字样前的小方框，选中检索到的文献。待需要选中的文献题目前的方框均出现对勾“√”，点击“导出/参考文献”。  

![v21cb817dad075d73d475d162a2cb43c40hd.jpg](https://img.hacpai.com/file/2019/10/v21cb817dad075d73d475d162a2cb43c40hd-b8958180.jpg)

#### 3、在新弹出的页面中，点击“NoteExpress”后，点击“导出”。
  
![v2c1b84b090eabc20c78d111cf2f3ba06dhd.jpg](https://img.hacpai.com/file/2019/10/v2c1b84b090eabc20c78d111cf2f3ba06dhd-7e7df10d.jpg)

#### 4、在NoteExpress中【文件】→【导入题录】，选择刚才下载的文件后，选择好过滤器，确定即可。

![20191009113441.jpg](https://img.hacpai.com/file/2019/10/20191009113441-f19d19f8.jpg)

更多格式可参见详细教程: [NoteExpress教程 | 文献检索和导出](https://zhuanlan.zhihu.com/p/25072525)

### 使用NoteExpress网络捕手插件

NoteExpress网络捕手是支持Chrome浏览器及Chromium内核浏览器的插件程序，可以将网页上的内容一键保存到NoteExpress当前数据库的任意指定目录，辅助用户高效收集资料。
#### 1、在Chrome应用商店中搜索“NoteExpress网络捕手”或 [点击此处](https://chrome.google.com/webstore/detail/noteexpress%E7%BD%91%E7%BB%9C%E6%8D%95%E6%89%8B/ljbhddngkkppbbkknjldoikonnolgafd?utm_source=chrome-ntp-icon)跳转，并点击右侧的“添加至Chrome”即可。

![800px插件图片1.png](https://img.hacpai.com/file/2019/10/800px插件图片1-1adbc556.png)

#### 2、安装教程可参见 [NoteExpress网络捕手安装使用说明](http://www.inoteexpress.com/wiki/index.php/NoteExpress网络捕手安装使用说明)

#### 3、与本地NoteExpress程序配合使用
NoteExpress网络捕手必须配合本地NoteExpress程序一起使用，如果本地的NoteExpress程序没有启动，点击插件时会启动本地NoteExpress程序。这类操作需要用户授权才能执行。如果您遇到如下的提示，请先勾选“记住我对此类链接的选择”，然后点击“启动应用”，本次NoteExpress程序启动后，再次点击浏览器插件，即可正常使用。

![800px插件图片11.png](https://img.hacpai.com/file/2019/10/800px插件图片11-cd5b4f51.png)

### 直接使用 NoteExpress 检索
NE集成了绝大部分常用的数据库，不用登陆到数据库页面，利用NE集成的在线检索作为网关即可检索获取题录信息。

#### 1、选择需要检索的数据库，在打开的界面中选择字段进行检索

![在线检索选择数据库.png](https://img.hacpai.com/file/2019/10/在线检索选择数据库-b2f6dc4c.png)

#### 2、输入检索词取回检索结果后，勾选所需要的题录。可以使用批量获取功能，一次性将检索题录全部导入软件

![在线检索批量获取.png](https://img.hacpai.com/file/2019/10/在线检索批量获取-1a550dcb.png)

#### 3、将获取题录导入软件进行查看 

![在线检索导入.png](https://img.hacpai.com/file/2019/10/在线检索导入-34b03d9e.png)

### Word插入参考文献

在NoteExpress中选中需要插入的参考文献题录，然后在Word中需要引用文献的位置选择“插入引文”按钮，该参考文献即可插入Word文档，且在文档最后自动生成参考文献列表。

或者在NoteExpress中选中需要插入的文献题录，点击“引用”按钮即可跳转到Word光标处并插入文献。

![word.jpg](https://img.hacpai.com/file/2019/10/word-f8297134.jpg)

当然，NoteExpress插件样式选项可更改不同的文献样式格式。

![format.jpg](https://img.hacpai.com/file/2019/10/format-1b05aebb.jpg)

### 总结

对于大多数使用NoteExpress的用户来说，使用NoteExpress管理文献的主要目的便是文章撰写。NoteExpress内置了多种国内外学术期刊、学位论文和国标的格式规范，通过NoteExpress插入文献，然后选择需要的格式进行格式化，可以**快速自动地生成参考文献**。

这样在写文章/论文的过程中，用户便可以从手工编辑与管理文献的繁重工作中解脱出来。而且可以根据需要随时调整参考文献的格式。当然如果NoteExpress没有需要的文献格式，也可以非常方便地编辑自己需要的格式。
