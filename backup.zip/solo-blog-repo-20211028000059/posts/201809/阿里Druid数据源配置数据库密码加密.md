title: 阿里Druid数据源配置数据库密码加密
date: '2018-09-19 01:36:05'
updated: '2019-10-15 09:50:23'
tags: [数据库, 加密安全]
permalink: /articles/2018/09/18/1537258285996.html
---
![](https://img.hacpai.com/bing/20180627.jpg?imageView2/1/w/960/h/520/interlace/1/q/100) 

## Druid是阿里巴巴开源平台上一个数据库连接池实现，它结合了C3P0、DBCP、PROXOOL等DB池的优点，同时加入了日志监控，可以很好的监控DB池连接和SQL的执行情况，可以说是针对监控而生的DB连接池!并且支持使用密码加密链接数据库！


## 一.生成密文密码

### 1. 生成密文密码
需要准备druid的jar包，然后通过命令行生成，如下步骤：(示例使用 druid-0.2.23.jar)，放到某目录下，且打开命令窗口(win用户可以在目录的空白处 shift+鼠标右键  打开命令窗口)：
![](https://7n.w3cschool.cn/attachments/image/20180321/1521625848512070.jpg)

### 2. 输入命令（you_password是要加密的密码，此处是123456pwd）：
> java -cp druid-0.2.23.jar com.alibaba.druid.filter.config.ConfigTools you_password


> java -cp druid-1.1.9.jar com.alibaba.druid.filter.config.ConfigTools  123456pwd  >aaa.txt

![](https://7n.w3cschool.cn/attachments/image/20180321/1521626525958407.png)

## 二、dataSource配置

### 1. jdbc.properties配置

```xml
  jdbc.url=jdbc:mysql://localhost:3306/niuniu?useUnicode=true&characterEncoding=utf-8
  jdbc.username=root
  jdbc.password=Obsbr4gd1oVyYr+k4KQdUMNYgKMWdDibsNJTabnph+yPmxjc6tUrT1GNsPDqa9ZvTF9QvaRD86H+Zn/H+yz2jA==
  jdbc.publickey= MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAKHGwq7q2RmwuRgKxBypQHw0mYu4BQZ3eMsTrdK8E6igRcxsobUC7uT0SoxIjl1WveWniCASejoQtn/BY6hVKWsCAwEAAQ==
```

### 2. dataSource配置

```xml
<!-- 基于Druid数据库链接池的数据源配置 -->
<bean id="dataSource" class="com.alibaba.druid.pool.DruidDataSource" init-method="init" destroy-method="close">
    <!-- 基本属性driverClassName、 url、user、password -->
    <property name="driverClassName" value="com.mysql.jdbc.Driver" />
    <property name="url" value="${jdbc.url}" />
    <property name="username" value="${jdbc.username}" />
    <property name="password" value="${jdbc.password}" />
    <!-- 解密密码必须要配置的项 -->
     <property name="filters" value="stat,config" />
    <property name="connectionProperties" value="config.decrypt=true;config.decrypt.key=${jdbc.publickey}" />
    <!-- 配置初始化大小、最小、最大 -->
    <!-- 通常来说，只需要修改initialSize、minIdle、maxActive -->
    <property name="initialSize" value="2" />
    <property name="minIdle" value="2" />
    <property name="maxActive" value="30" />
    <property name="testWhileIdle" value="false" />
    <!-- 配置获取连接等待超时的时间 -->
    <property name="maxWait" value="5000" />
    <!-- 配置一个连接在池中最小生存的时间，单位是毫秒 -->
    <property name="minEvictableIdleTimeMillis" value="30000" />
    <!-- 配置间隔多久才进行一次检测，检测需要关闭的空闲连接，单位是毫秒 -->
    <property name="timeBetweenEvictionRunsMillis" value="60000" />
</bean>
```
