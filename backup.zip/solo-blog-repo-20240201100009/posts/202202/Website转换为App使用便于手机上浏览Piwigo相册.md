title: Website转换为App使用，便于手机上浏览Piwigo相册
date: '2022-02-06 20:52:48'
updated: '2022-02-07 09:49:22'
tags: [相册, 工具]
permalink: /articles/2022/02/06/1644151968525.html
---
为便于在Android手机上查看Piwigo相册内容，一般有两种方法，一是采用Piwigo的Android客户端，如https://github.com/Piwigo/Piwigo-Android 和 https://m.apkpure.com/piwigo-ng/com.piwigo.piwigo_ng，但发现客户端功能不是很完善，打开相册很慢（可能是我相册带宽太小了）；二是直接采用手机上的浏览器直接打开相册地址。但这两种方案对老人都不是很友好，因此，该文用于记录将Website转换为App的过程，以备查。

经过Google，发现目前来说，采用`Website 2 APK Builder Pro`软件生成的App最稳定，方法最简便，如下图示。

![image.png](https://b3logfile.com/file/2022/02/image-89e0608a.png)

生成的App在手机上生成结果如图所示。

![image.png](https://b3logfile.com/file/2022/02/image-a71fd2ee.png)

大功告成，记录备用。

参见：
https://websitetoapk.com/docs/creating-keystore-for-signing.html

https://zxniuniu.lanzouw.com/iqtdmzof8fc#niuniu

https://websitetoapk.com/docs/configure-extras-options.html

